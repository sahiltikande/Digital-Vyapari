package com.digitalvyapari.Controller;

import com.digitalvyapari.Utils.FirebaseUtil;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import org.json.JSONObject;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Scanner;

/**
 * LoginController - Handles Firebase Authentication REST API.
 * Manages login, registration, and saves user profile data.
 */
public class LoginController {

    private static final String FIREBASE_API_KEY = "AIzaSyDtyHp-P96Fkd4NxgNQ1xk7L3iMA9kUoSQ";
    private static final String SIGN_IN_URL = "https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=";
    private static final String SIGN_UP_URL = "https://identitytoolkit.googleapis.com/v1/accounts:signUp?key=";

    /**
     * @return null on success, error message on failure
     */
    public static LoginResult login(String email, String password) {
        try {
            HttpURLConnection conn = createConnection(SIGN_IN_URL + FIREBASE_API_KEY);

            String payload = new JSONObject()
                    .put("email", email)
                    .put("password", password)
                    .put("returnSecureToken", true)
                    .toString();

            try (OutputStream os = conn.getOutputStream()) {
                os.write(payload.getBytes());
            }

            if (conn.getResponseCode() == 200) {
                String response = new Scanner(conn.getInputStream()).useDelimiter("\\A").next();
                JSONObject json = new JSONObject(response);
                String uid = json.getString("localId");
                String displayName = json.optString("displayName", "");
                return new LoginResult(null, uid, displayName);
            } else {
                return new LoginResult(parseErrorMessage(conn), null, null);
            }
        } catch (Exception e) {
            e.printStackTrace();
            return new LoginResult("Connection error: " + e.getMessage(), null, null);
        }
    }

    /**
     * @return null on success, error message on failure
     */
    public static String register(String email, String password, String name,
                                   String address, String mobile, String role) {
        try {
            HttpURLConnection conn = createConnection(SIGN_UP_URL + FIREBASE_API_KEY);

            String payload = new JSONObject()
                    .put("email", email)
                    .put("password", password)
                    .put("returnSecureToken", true)
                    .toString();

            try (OutputStream os = conn.getOutputStream()) {
                os.write(payload.getBytes());
            }

            if (conn.getResponseCode() == 200) {
                String response = new Scanner(conn.getInputStream()).useDelimiter("\\A").next();
                String uid = new JSONObject(response).getString("localId");

                // Save profile in Firebase Realtime DB
                FirebaseUtil.initialize();
                DatabaseReference userRef = FirebaseDatabase.getInstance()
                        .getReference("users").child(uid);
                userRef.child("email").setValueAsync(email);
                userRef.child("name").setValueAsync(name);
                userRef.child("mobile").setValueAsync(mobile);
                userRef.child("address").setValueAsync(address);
                userRef.child("role").setValueAsync(role);
                userRef.child("createdAt").setValueAsync(System.currentTimeMillis());

                return null; // success
            } else {
                return parseErrorMessage(conn);
            }
        } catch (Exception e) {
            e.printStackTrace();
            return "Registration error: " + e.getMessage();
        }
    }

    private static HttpURLConnection createConnection(String urlStr) throws Exception {
        URL url = new URL(urlStr);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("POST");
        conn.setRequestProperty("Content-Type", "application/json");
        conn.setDoOutput(true);
        conn.setConnectTimeout(8000);
        conn.setReadTimeout(8000);
        return conn;
    }

    private static String parseErrorMessage(HttpURLConnection conn) {
        try {
            String errorResponse = new Scanner(conn.getErrorStream()).useDelimiter("\\A").next();
            JSONObject errorJson = new JSONObject(errorResponse).getJSONObject("error");
            String message = errorJson.optString("message", "UNKNOWN_ERROR");

            // Try inner errors array first
            if (errorJson.has("errors")) {
                String innerMsg = errorJson.getJSONArray("errors")
                        .getJSONObject(0).optString("message", message);
                message = innerMsg;
            }

            switch (message) {
                case "EMAIL_NOT_FOUND":
                case "INVALID_PASSWORD":
                case "INVALID_LOGIN_CREDENTIALS":
                    return "Invalid email or password.";
                case "USER_DISABLED":
                    return "This account has been disabled.";
                case "EMAIL_EXISTS":
                    return "This email is already registered.";
                case "INVALID_EMAIL":
                    return "Invalid email format.";
                case "WEAK_PASSWORD : Password should be at least 6 characters":
                    return "Password must be at least 6 characters.";
                case "TOO_MANY_ATTEMPTS_TRY_LATER":
                    return "Too many failed attempts. Please try later.";
                default:
                    return "Authentication failed: " + message;
            }
        } catch (Exception e) {
            return "Authentication failed (unknown error).";
        }
    }

    public static class LoginResult {
        public final String error;
        public final String uid;
        public final String displayName;

        public LoginResult(String error, String uid, String displayName) {
            this.error = error;
            this.uid = uid;
            this.displayName = displayName;
        }

        public boolean isSuccess() { return error == null; }
    }
}
