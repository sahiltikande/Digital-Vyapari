package com.digitalvyapari.Controller;

import com.digitalvyapari.Utils.FirebaseUtil;
import com.google.firebase.database.*;

import java.util.*;
import java.util.concurrent.CountDownLatch;
import java.util.stream.Collectors;

/**
 * MaterialController - Manages material/inventory data from Firebase.
 * Includes AI-driven insights like top sellers and slow movers.
 */
public class MaterialController {

    // ── Data Model ───────────────────────────────────────────────────────────

    public static class MaterialEntry {
        private final String key;
        private final String type;
        private final String material;
        private double quantity;
        private double rate;
        private final double finalPrice;
        private final long timestamp;
        private final String farmerName;

        public MaterialEntry(String key, String type, String material,
                             double quantity, double rate, long timestamp, String farmerName) {
            this.key = key;
            this.type = type;
            this.material = material;
            this.quantity = quantity;
            this.rate = rate;
            this.finalPrice = quantity * rate;
            this.timestamp = timestamp;
            this.farmerName = farmerName != null ? farmerName : "Unknown";
        }

        public String getKey()        { return key; }
        public String getType()       { return type; }
        public String getMaterial()   { return material; }
        public double getQuantity()   { return quantity; }
        public void setQuantity(double q) { this.quantity = q; }
        public double getRate()       { return rate; }
        public double getFinalPrice() { return finalPrice; }
        public long getTimestamp()    { return timestamp; }
        public String getFarmerName() { return farmerName; }

        // For int compatibility
        public int getQuantityInt()   { return (int) quantity; }
        public int getRateInt()       { return (int) rate; }
        public int getFinalPriceInt() { return (int) finalPrice; }

        public boolean isLowStock()   { return quantity < 10; }

        @Override
        public String toString() {
            return String.format("MaterialEntry{type='%s', material='%s', qty=%.1f, rate=%.1f}",
                    type, material, quantity, rate);
        }
    }

    // ── Firebase Reads ────────────────────────────────────────────────────────

    /** Fetch all material entries (one-time read, blocks until done) */
    public static List<MaterialEntry> getMaterialData() {
        FirebaseUtil.initialize();
        List<MaterialEntry> materials = new ArrayList<>();

        if (!FirebaseUtil.isInitialized()) {
            System.err.println("[Firebase] Not initialized; cannot fetch materials.");
            return materials;
        }

        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("farmer_data");
        CountDownLatch latch = new CountDownLatch(1);

        ref.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                for (DataSnapshot child : snapshot.getChildren()) {
                    try {
                        String type     = child.child("materialType").getValue(String.class);
                        String material = child.child("material").getValue(String.class);
                        String name     = child.child("name").getValue(String.class);

                        Double qtyD = child.child("quantity").getValue(Double.class);
                        Double rateD = child.child("rate").getValue(Double.class);
                        if (qtyD == null) {
                            Long qtyL = child.child("quantity").getValue(Long.class);
                            qtyD = qtyL != null ? qtyL.doubleValue() : 0.0;
                        }
                        if (rateD == null) {
                            Long rateL = child.child("rate").getValue(Long.class);
                            rateD = rateL != null ? rateL.doubleValue() : 0.0;
                        }

                        Long ts = child.child("timestamp").getValue(Long.class);
                        long timestamp = ts != null ? ts : 0L;

                        if (type != null && material != null) {
                            materials.add(new MaterialEntry(child.getKey(), type, material,
                                    qtyD, rateD, timestamp, name));
                        }
                    } catch (Exception e) {
                        System.err.println("[Firebase] Skipping record: " + child.getKey() + " - " + e.getMessage());
                    }
                }
                latch.countDown();
            }

            @Override
            public void onCancelled(DatabaseError error) {
                System.err.println("[Firebase] getMaterialData cancelled: " + error.getMessage());
                latch.countDown();
            }
        });

        try { latch.await(); }
        catch (InterruptedException e) { Thread.currentThread().interrupt(); }

        return materials;
    }

    /** Real-time listener - calls callback whenever data changes */
    public static ValueEventListener listenToMaterials(Runnable onDataChange) {
        FirebaseUtil.initialize();
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("farmer_data");

        ValueEventListener listener = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                if (onDataChange != null) onDataChange.run();
            }
            @Override
            public void onCancelled(DatabaseError error) {
                System.err.println("[Firebase] Real-time listener cancelled: " + error.getMessage());
            }
        };
        ref.addValueEventListener(listener);
        return listener;
    }

    // ── Dashboard Stats ──────────────────────────────────────────────────────

    public static Map<String, Object> getDashboardStats(List<MaterialEntry> entries) {
        Map<String, Object> stats = new HashMap<>();

        double totalValue = entries.stream().mapToDouble(MaterialEntry::getFinalPrice).sum();
        double totalQty   = entries.stream().mapToDouble(MaterialEntry::getQuantity).sum();
        long lowStockCount = entries.stream().filter(MaterialEntry::isLowStock).count();
        long typesCount   = entries.stream().map(MaterialEntry::getType).distinct().count();

        stats.put("totalValue", totalValue);
        stats.put("totalQuantity", totalQty);
        stats.put("lowStockCount", lowStockCount);
        stats.put("typesCount", typesCount);
        stats.put("totalRecords", entries.size());

        return stats;
    }

    // ── AI Insights ──────────────────────────────────────────────────────────

    /** Returns top 5 materials by quantity (top sellers) */
    public static List<MaterialEntry> getTopSellers(List<MaterialEntry> entries) {
        return entries.stream()
                .sorted(Comparator.comparingDouble(MaterialEntry::getQuantity).reversed())
                .limit(5)
                .collect(Collectors.toList());
    }

    /** Returns materials with low stock (< 10 units) */
    public static List<MaterialEntry> getLowStockItems(List<MaterialEntry> entries) {
        return entries.stream()
                .filter(MaterialEntry::isLowStock)
                .sorted(Comparator.comparingDouble(MaterialEntry::getQuantity))
                .collect(Collectors.toList());
    }

    /** Returns slow-moving materials (bottom 5 by quantity) */
    public static List<MaterialEntry> getSlowMovers(List<MaterialEntry> entries) {
        return entries.stream()
                .sorted(Comparator.comparingDouble(MaterialEntry::getQuantity))
                .limit(5)
                .collect(Collectors.toList());
    }

    /** Group quantities by material type */
    public static Map<String, Double> getQuantityByType(List<MaterialEntry> entries) {
        return entries.stream()
                .collect(Collectors.groupingBy(
                        MaterialEntry::getType,
                        Collectors.summingDouble(MaterialEntry::getQuantity)
                ));
    }

    /** Group total value by material type */
    public static Map<String, Double> getValueByType(List<MaterialEntry> entries) {
        return entries.stream()
                .collect(Collectors.groupingBy(
                        MaterialEntry::getType,
                        Collectors.summingDouble(MaterialEntry::getFinalPrice)
                ));
    }

    /** Smart product suggestions based on most common material type */
    public static List<String> getSmartSuggestions(List<MaterialEntry> entries, String query) {
        if (query == null || query.trim().isEmpty()) return Collections.emptyList();

        String q = query.toLowerCase().trim();
        return entries.stream()
                .map(MaterialEntry::getMaterial)
                .distinct()
                .filter(m -> m.toLowerCase().contains(q))
                .limit(8)
                .collect(Collectors.toList());
    }

    /** Get total revenue estimate */
    public static double getTotalInventoryValue(List<MaterialEntry> entries) {
        return entries.stream().mapToDouble(MaterialEntry::getFinalPrice).sum();
    }
}
