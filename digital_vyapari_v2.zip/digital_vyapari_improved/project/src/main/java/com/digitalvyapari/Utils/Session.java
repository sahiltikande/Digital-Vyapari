package com.digitalvyapari.Utils;

/**
 * Session - Holds current logged-in user information.
 */
public class Session {
    private static String currentUserUid;
    private static String currentUserName;
    private static String currentUserEmail;
    private static String currentUserRole;
    private static boolean darkMode = false;

    public static void setUser(String uid, String name, String email, String role) {
        currentUserUid = uid;
        currentUserName = name;
        currentUserEmail = email;
        currentUserRole = role;
    }

    public static void setCurrentUser(String uid) { currentUserUid = uid; }
    public static String getCurrentUser() { return currentUserUid; }

    public static String getCurrentUserName() { return currentUserName != null ? currentUserName : "User"; }
    public static String getCurrentUserEmail() { return currentUserEmail != null ? currentUserEmail : ""; }
    public static String getCurrentUserRole() { return currentUserRole != null ? currentUserRole : ""; }

    public static boolean isDarkMode() { return darkMode; }
    public static void toggleDarkMode() { darkMode = !darkMode; }
    public static void setDarkMode(boolean value) { darkMode = value; }

    public static void clear() {
        currentUserUid = null;
        currentUserName = null;
        currentUserEmail = null;
        currentUserRole = null;
    }

    public static boolean isLoggedIn() {
        return currentUserUid != null && !currentUserUid.isEmpty();
    }
}
