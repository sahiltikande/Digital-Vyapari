package com.digitalvyapari.view;

import com.digitalvyapari.Controller.FarmerController;
import com.digitalvyapari.Utils.UIHelper;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

public class Farmer extends Application {

    private Label totalPriceLabel = new Label("₹ 0.00");
    private boolean submitted = false;
    private double lastQty = 0, lastRate = 0, lastTotal = 0;
    private String lastMaterial = "", lastName = "", lastEmail = "";
    private String lastAddress = "", lastType = "", lastMaterialName = "";

    @Override
    public void start(Stage stage) {
        stage.setTitle("Digital Vyapari - Farmer Entry");

        Sidebar sidebar = new Sidebar(stage, "Farmer Entry");

        BorderPane mainArea = new BorderPane();
        mainArea.setStyle("-fx-background-color: #F0F4F8;");
        mainArea.setTop(buildTopBar(stage));
        mainArea.setCenter(buildForm(stage));

        HBox root = new HBox(sidebar, mainArea);
        HBox.setHgrow(mainArea, Priority.ALWAYS);

        Scene scene = new Scene(root, 1400, 850);
        stage.setScene(scene);
        stage.setFullScreen(true);
        stage.show();
    }

    private HBox buildTopBar(Stage stage) {
        Label title = new Label("🌾 Farmer Material Entry");
        title.setFont(Font.font("Segoe UI", FontWeight.BOLD, 22));
        title.setStyle("-fx-text-fill: #2C3E50;");

        Label sub = new Label("Record farmer supply and generate invoice");
        sub.setStyle("-fx-text-fill: #7F8C8D; -fx-font-size: 13px;");

        VBox titleBox = new VBox(2, title, sub);
        Region spacer = new Region(); HBox.setHgrow(spacer, Priority.ALWAYS);

        Button backBtn = UIHelper.outlineButton("← Back to Dashboard");
        backBtn.setOnAction(e -> new VyapariHome().start(stage));

        HBox bar = new HBox(16, titleBox, spacer, backBtn);
        bar.setAlignment(Pos.CENTER_LEFT);
        bar.setPadding(new Insets(16, 24, 16, 24));
        bar.setStyle(
            "-fx-background-color: white;" +
            "-fx-border-color: #E8EAED;" +
            "-fx-border-width: 0 0 1 0;" +
            "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.06), 6, 0, 0, 2);"
        );
        return bar;
    }

    private ScrollPane buildForm(Stage stage) {
        // ── Input fields ───────────────────────────────────────────────────────
        TextField nameField     = UIHelper.styledTextField("Enter farmer's full name");
        TextField emailField    = UIHelper.styledTextField("Enter email address");
        TextField addressField  = UIHelper.styledTextField("Enter full address");
        TextField materialField = UIHelper.styledTextField("e.g. Tomatoes, Wheat, Mango");
        TextField qtyField      = UIHelper.styledTextField("Quantity in kg");
        TextField rateField     = UIHelper.styledTextField("Rate per kg in ₹");

        ComboBox<String> typeCombo = UIHelper.styledComboBox("Select category");
        typeCombo.getItems().addAll("Vegetables", "Fruits", "Sprouts", "Grains", "Dairy", "Spices", "Other");
        typeCombo.setPrefWidth(300);

        // ── Live price calculation ────────────────────────────────────────────
        totalPriceLabel.setFont(Font.font("Segoe UI", FontWeight.BOLD, 28));
        totalPriceLabel.setStyle("-fx-text-fill: #27AE60;");

        Runnable calcPrice = () -> {
            try {
                double qty  = Double.parseDouble(qtyField.getText().trim());
                double rate = Double.parseDouble(rateField.getText().trim());
                totalPriceLabel.setText("₹ " + String.format("%.2f", qty * rate));
            } catch (Exception ignored) {}
        };
        qtyField.textProperty().addListener((o, old, n) -> calcPrice.run());
        rateField.textProperty().addListener((o, old, n) -> calcPrice.run());

        // ── Price card ────────────────────────────────────────────────────────
        Label priceTitle = new Label("Calculated Total");
        priceTitle.setStyle("-fx-text-fill: #7F8C8D; -fx-font-size: 13px;");

        VBox priceCard = new VBox(4, priceTitle, totalPriceLabel);
        priceCard.setAlignment(Pos.CENTER);
        priceCard.setPadding(new Insets(20));
        priceCard.setStyle(
            "-fx-background-color: white;" +
            "-fx-background-radius: 12;" +
            "-fx-border-color: #27AE60;" +
            "-fx-border-width: 2;" +
            "-fx-border-radius: 12;" +
            "-fx-effect: dropshadow(gaussian, rgba(39,174,96,0.2), 10, 0, 0, 3);"
        );

        // ── Buttons ───────────────────────────────────────────────────────────
        Button submitBtn = UIHelper.primaryButton("✅  Submit & Save");
        submitBtn.setPrefWidth(200);
        submitBtn.setPrefHeight(44);

        Button pdfBtn = UIHelper.warningButton("📄  Print Invoice");
        pdfBtn.setPrefWidth(200);
        pdfBtn.setPrefHeight(44);
        pdfBtn.setDisable(true);

        Button clearBtn = UIHelper.outlineButton("🗑  Clear Form");
        clearBtn.setPrefWidth(160);

        submitBtn.setOnAction(e -> {
            if (validateForm(nameField, emailField, addressField, typeCombo, materialField, qtyField, rateField))
                return;
            try {
                lastQty  = Double.parseDouble(qtyField.getText().trim());
                lastRate = Double.parseDouble(rateField.getText().trim());
                lastTotal = lastQty * lastRate;
                lastName  = nameField.getText().trim();
                lastEmail = emailField.getText().trim();
                lastAddress = addressField.getText().trim();
                lastType  = typeCombo.getValue();
                lastMaterialName = materialField.getText().trim().toLowerCase();

                submitBtn.setText("Saving..."); submitBtn.setDisable(true);

                new Thread(() -> {
                    FarmerController.submitToFirebase(
                        lastName, lastEmail, lastAddress,
                        lastType, lastMaterialName,
                        String.valueOf(lastQty), String.valueOf(lastRate)
                    );
                    javafx.application.Platform.runLater(() -> {
                        submitted = true;
                        pdfBtn.setDisable(false);
                        submitBtn.setText("✅  Submit & Save");
                        submitBtn.setDisable(false);
                        UIHelper.showInfo("Success", "Farmer data saved successfully!");
                    });
                }).start();

            } catch (NumberFormatException ex) {
                UIHelper.showError("Invalid Input", "Quantity and rate must be valid numbers.");
            }
        });

        pdfBtn.setOnAction(e -> {
            if (submitted) {
                new Thread(() -> FarmerController.generatePDF(
                    lastName, lastEmail, lastAddress,
                    lastType, lastMaterialName,
                    lastQty, lastRate, lastTotal
                )).start();
            }
        });

        clearBtn.setOnAction(e -> {
            nameField.clear(); emailField.clear(); addressField.clear();
            materialField.clear(); qtyField.clear(); rateField.clear();
            typeCombo.setValue(null); totalPriceLabel.setText("₹ 0.00");
            pdfBtn.setDisable(true); submitted = false;
        });

        HBox btnRow = new HBox(12, submitBtn, pdfBtn, clearBtn);
        btnRow.setAlignment(Pos.CENTER_LEFT);

        // ── Form grid ────────────────────────────────────────────────────────
        GridPane grid = new GridPane();
        grid.setHgap(20); grid.setVgap(16);
        grid.setAlignment(Pos.TOP_LEFT);

        addFormRow(grid, "👤  Farmer Name *", nameField, 0);
        addFormRow(grid, "📧  Email Address", emailField, 1);
        addFormRow(grid, "🏠  Address", addressField, 2);
        addFormRow(grid, "📦  Material Category *", typeCombo, 3);
        addFormRow(grid, "🌾  Material Name *", materialField, 4);
        addFormRow(grid, "⚖️  Quantity (kg) *", qtyField, 5);
        addFormRow(grid, "💰  Rate per kg (₹) *", rateField, 6);

        // ── Form card ─────────────────────────────────────────────────────────
        Label formTitle = new Label("📋 Entry Details");
        formTitle.setFont(Font.font("Segoe UI", FontWeight.BOLD, 16));
        formTitle.setStyle("-fx-text-fill: #2C3E50;");

        VBox formCard = new VBox(16, formTitle, new Separator(), grid, priceCard, btnRow);
        formCard.setPadding(new Insets(24));
        formCard.setMaxWidth(720);
        formCard.setStyle(
            "-fx-background-color: white;" +
            "-fx-background-radius: 14;" +
            "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.09), 12, 0, 0, 4);"
        );

        // ── Tips card ─────────────────────────────────────────────────────────
        VBox tipsCard = buildTipsCard();

        HBox layout = new HBox(20, formCard, tipsCard);
        layout.setPadding(new Insets(24));
        layout.setAlignment(Pos.TOP_LEFT);

        ScrollPane scroll = new ScrollPane(layout);
        scroll.setFitToWidth(true);
        scroll.setStyle("-fx-background-color: #F0F4F8; -fx-border-color: transparent;");
        return scroll;
    }

    private void addFormRow(GridPane grid, String labelText, javafx.scene.Node field, int row) {
        Label lbl = new Label(labelText);
        lbl.setFont(Font.font("Segoe UI", FontWeight.SEMI_BOLD, 13));
        lbl.setStyle("-fx-text-fill: #5D6D7E;");
        lbl.setMinWidth(190);
        grid.add(lbl, 0, row);
        grid.add(field, 1, row);
        if (field instanceof TextField) {
            ((TextField) field).setPrefWidth(340);
        } else if (field instanceof ComboBox) {
            ((ComboBox<?>) field).setPrefWidth(340);
        }
    }

    private boolean validateForm(TextField name, TextField email, TextField address,
                                  ComboBox<String> type, TextField material,
                                  TextField qty, TextField rate) {
        if (name.getText().trim().isEmpty() || material.getText().trim().isEmpty()
                || qty.getText().trim().isEmpty() || rate.getText().trim().isEmpty()
                || type.getValue() == null) {
            UIHelper.showWarning("Incomplete Form", "Please fill in all required fields (marked with *).");
            return true;
        }
        try {
            Double.parseDouble(qty.getText().trim());
            Double.parseDouble(rate.getText().trim());
        } catch (NumberFormatException e) {
            UIHelper.showError("Invalid Input", "Quantity and rate must be valid numbers.");
            return true;
        }
        return false;
    }

    private VBox buildTipsCard() {
        Label title = new Label("💡 Quick Tips");
        title.setFont(Font.font("Segoe UI", FontWeight.BOLD, 15));
        title.setStyle("-fx-text-fill: #2C3E50;");

        String[] tips = {
            "📌 Fields marked with * are required",
            "📌 Price is auto-calculated as Qty × Rate",
            "📌 Click Submit to save to Firebase",
            "📌 Print Invoice generates a PDF file",
            "📌 Material name is saved in lowercase",
            "📌 Check Analytics for top sellers",
            "📌 Low stock alert triggers below 10 kg"
        };

        VBox tipsBox = new VBox(10);
        for (String tip : tips) {
            Label l = new Label(tip);
            l.setStyle("-fx-text-fill: #5D6D7E; -fx-font-size: 13px;");
            l.setWrapText(true);
            tipsBox.getChildren().add(l);
        }

        VBox card = new VBox(14, title, new Separator(), tipsBox);
        card.setPadding(new Insets(20));
        card.setMaxWidth(280);
        card.setMinWidth(240);
        card.setStyle(
            "-fx-background-color: white;" +
            "-fx-background-radius: 14;" +
            "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.09), 12, 0, 0, 4);"
        );
        return card;
    }
}
