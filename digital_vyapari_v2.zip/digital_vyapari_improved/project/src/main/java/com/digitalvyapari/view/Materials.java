package com.digitalvyapari.view;

// Legacy compatibility stub - redirects to MaterialsView
import javafx.application.Application;
import javafx.stage.Stage;

public class Materials extends Application {
    @Override
    public void start(Stage stage) {
        new MaterialsView().start(stage);
    }
}
