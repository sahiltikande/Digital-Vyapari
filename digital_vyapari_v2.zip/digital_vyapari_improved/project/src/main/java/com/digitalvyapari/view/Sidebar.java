package com.digitalvyapari.view;

import com.digitalvyapari.Utils.Session;
import com.digitalvyapari.Utils.UIHelper;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Separator;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

import java.util.ArrayList;
import java.util.List;

/**
 * Sidebar - Reusable sidebar navigation for dashboard layouts.
 */
public class Sidebar extends VBox {

    public interface NavAction {
        void execute(Stage stage);
    }

    private final List<Button> navButtons = new ArrayList<>();
    private Button activeButton;

    public Sidebar(Stage stage, String activeLabel) {
        super(0);
        setStyle("-fx-background-color: #1A252F; -fx-min-width: 220px; -fx-pref-width: 220px;");
        setPrefHeight(Double.MAX_VALUE);

        // ── Logo area ────────────────────────────────────────────────────────
        Circle logoCircle = new Circle(20);
        logoCircle.setFill(Color.web("#27AE60"));
        Label logoText = new Label("DV");
        logoText.setFont(Font.font("Segoe UI", FontWeight.BOLD, 14));
        logoText.setStyle("-fx-text-fill: white;");
        javafx.scene.layout.StackPane logo = new javafx.scene.layout.StackPane(logoCircle, logoText);

        Label appName = new Label("Digital Vyapari");
        appName.setFont(Font.font("Segoe UI", FontWeight.BOLD, 16));
        appName.setStyle("-fx-text-fill: white;");

        VBox logoBox = new VBox(4, logo, appName);
        logoBox.setAlignment(Pos.CENTER);
        logoBox.setPadding(new Insets(24, 12, 20, 12));

        // ── User info ─────────────────────────────────────────────────────────
        Label userName = new Label(Session.getCurrentUserName());
        userName.setFont(Font.font("Segoe UI", FontWeight.SEMI_BOLD, 13));
        userName.setStyle("-fx-text-fill: white;");
        Label userRole = new Label(Session.getCurrentUserRole());
        userRole.setStyle("-fx-text-fill: rgba(255,255,255,0.5); -fx-font-size: 11px;");

        Circle avatar = new Circle(18);
        avatar.setFill(Color.web("#27AE60"));
        Label avatarLetter = new Label(Session.getCurrentUserName().substring(0, 1).toUpperCase());
        avatarLetter.setStyle("-fx-text-fill: white; -fx-font-weight: bold; -fx-font-size: 14px;");
        javafx.scene.layout.StackPane avatarPane = new javafx.scene.layout.StackPane(avatar, avatarLetter);

        VBox nameBox = new VBox(2, userName, userRole);
        nameBox.setAlignment(Pos.CENTER_LEFT);
        javafx.scene.layout.HBox userBox = new javafx.scene.layout.HBox(10, avatarPane, nameBox);
        userBox.setAlignment(Pos.CENTER_LEFT);
        userBox.setPadding(new Insets(10, 14, 14, 14));
        userBox.setStyle("-fx-background-color: rgba(255,255,255,0.06);");

        // ── Divider ───────────────────────────────────────────────────────────
        Separator sep1 = new Separator();
        sep1.setStyle("-fx-background-color: rgba(255,255,255,0.1);");

        // ── Navigation items (dynamic based on role) ──────────────────────────
        getChildren().addAll(logoBox, userBox, sep1);

        boolean isVyapari = "Vyapari".equalsIgnoreCase(Session.getCurrentUserRole());

        if (isVyapari) {
            addNavItem(stage, "🏠  Dashboard",     activeLabel, e -> new VyapariHome().start(stage));
            addNavItem(stage, "🌾  Farmer Entry",   activeLabel, e -> new Farmer().start(stage));
            addNavItem(stage, "📦  Materials",      activeLabel, e -> new MaterialsView().start(stage));
            addNavItem(stage, "📊  Analytics",      activeLabel, e -> new AnalyticsView().start(stage));
            addNavItem(stage, "👥  About Us",       activeLabel, e -> new AboutUs().start(stage));
        } else {
            addNavItem(stage, "🏠  Dashboard",      activeLabel, e -> new ShopkeeperHomePage().start(stage));
            addNavItem(stage, "🛒  Buy Materials",  activeLabel, e -> new ShopkeeperHomePage().start(stage));
            addNavItem(stage, "📋  My Orders",      activeLabel, e -> new OrdersPage().start(stage));
        }

        // ── Bottom: settings + logout ──────────────────────────────────────────
        VBox bottom = new VBox(0);
        VBox spacer = new VBox(); VBox.setVgrow(spacer, javafx.scene.layout.Priority.ALWAYS);

        Separator sep2 = new Separator();
        sep2.setStyle("-fx-background-color: rgba(255,255,255,0.1);");

        // Dark mode toggle
        Button darkBtn = sidebarButton("🌙  Dark Mode", false);
        darkBtn.setOnAction(e -> {
            Session.toggleDarkMode();
            darkBtn.setText(Session.isDarkMode() ? "☀️  Light Mode" : "🌙  Dark Mode");
        });

        Button logoutBtn = sidebarButton("🚪  Logout", false);
        logoutBtn.setStyle(logoutBtn.getStyle().replace("#BDC3C7", "#E74C3C"));
        logoutBtn.setOnAction(e -> {
            Session.clear();
            new WelcomePage().start(stage);
        });

        bottom.getChildren().addAll(sep2, darkBtn, logoutBtn);
        bottom.setPadding(new Insets(0, 0, 10, 0));

        getChildren().addAll(spacer, bottom);
    }

    private void addNavItem(Stage stage, String label, String activeLabel, NavAction action) {
        Button btn = sidebarButton(label, label.contains(activeLabel) || label.equals(activeLabel));
        btn.setOnAction(e -> action.execute(stage));
        if (label.contains(activeLabel)) {
            activeButton = btn;
        }
        navButtons.add(btn);
        getChildren().add(btn);
    }

    private Button sidebarButton(String text, boolean active) {
        Button btn = new Button(text);
        btn.setPrefWidth(220);
        btn.setAlignment(Pos.CENTER_LEFT);
        btn.setCursor(javafx.scene.Cursor.HAND);
        btn.setFont(Font.font("Segoe UI", 13));
        if (active) {
            btn.setStyle(
                "-fx-background-color: #27AE60;" +
                "-fx-text-fill: white;" +
                "-fx-font-weight: bold;" +
                "-fx-background-radius: 0;" +
                "-fx-padding: 12 20 12 20;" +
                "-fx-alignment: CENTER_LEFT;"
            );
        } else {
            btn.setStyle(
                "-fx-background-color: transparent;" +
                "-fx-text-fill: #BDC3C7;" +
                "-fx-background-radius: 0;" +
                "-fx-padding: 12 20 12 20;" +
                "-fx-alignment: CENTER_LEFT;"
            );
            btn.setOnMouseEntered(ev -> btn.setStyle(
                "-fx-background-color: rgba(255,255,255,0.08);" +
                "-fx-text-fill: white;" +
                "-fx-background-radius: 0;" +
                "-fx-padding: 12 20 12 20;" +
                "-fx-alignment: CENTER_LEFT;"
            ));
            btn.setOnMouseExited(ev -> btn.setStyle(
                "-fx-background-color: transparent;" +
                "-fx-text-fill: #BDC3C7;" +
                "-fx-background-radius: 0;" +
                "-fx-padding: 12 20 12 20;" +
                "-fx-alignment: CENTER_LEFT;"
            ));
        }
        return btn;
    }
}
