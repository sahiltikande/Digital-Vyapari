package com.digitalvyapari.Utils;

import com.google.auth.oauth2.GoogleCredentials;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;

import java.io.InputStream;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * FirebaseUtil - Singleton Firebase initializer.
 * Thread-safe, idempotent initialization with clear error reporting.
 */
public class FirebaseUtil {

    private static final AtomicBoolean initialized = new AtomicBoolean(false);
    private static final String DATABASE_URL = "https://myfxproject-cc36b-default-rtdb.firebaseio.com/";

    public static synchronized void initialize() {
        if (initialized.get()) return;

        try {
            // Try loading from classpath root
            InputStream serviceAccount = FirebaseUtil.class.getClassLoader()
                    .getResourceAsStream("firebase-key.json");

            if (serviceAccount == null) {
                serviceAccount = FirebaseUtil.class.getResourceAsStream("/firebase-key.json");
            }

            if (serviceAccount == null) {
                System.err.println("[Firebase] ERROR: firebase-key.json not found in resources.");
                System.err.println("[Firebase] Please ensure firebase-key.json is in src/main/resources/");
                return;
            }

            FirebaseOptions options = FirebaseOptions.builder()
                    .setCredentials(GoogleCredentials.fromStream(serviceAccount))
                    .setDatabaseUrl(DATABASE_URL)
                    .build();

            if (FirebaseApp.getApps().isEmpty()) {
                FirebaseApp.initializeApp(options);
                System.out.println("[Firebase] ✅ Initialized successfully.");
            }

            initialized.set(true);

        } catch (Exception ex) {
            System.err.println("[Firebase] ❌ Initialization failed: " + ex.getMessage());
            ex.printStackTrace();
        }
    }

    public static boolean isInitialized() {
        return initialized.get();
    }

    /** Reinitialize (for testing / reconnect scenarios) */
    public static void reset() {
        initialized.set(false);
    }
}
