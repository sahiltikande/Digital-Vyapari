package com.digitalvyapari.view;

import javafx.application.Application;
import javafx.geometry.*;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.text.*;
import javafx.stage.Stage;

public class AboutUs extends Application {

    @Override
    public void start(Stage stage) {
        stage.setTitle("Digital Vyapari - About Us");

        Sidebar sidebar = new Sidebar(stage, "About Us");

        BorderPane mainArea = new BorderPane();
        mainArea.setStyle("-fx-background-color: #F0F4F8;");
        mainArea.setTop(buildTopBar());
        mainArea.setCenter(buildContent());

        HBox root = new HBox(sidebar, mainArea);
        HBox.setHgrow(mainArea, Priority.ALWAYS);

        Scene scene = new Scene(root, 1400, 850);
        stage.setScene(scene);
        stage.setFullScreen(true);
        stage.show();
    }

    private HBox buildTopBar() {
        Label title = new Label("👥 About Us");
        title.setFont(Font.font("Segoe UI", FontWeight.BOLD, 22));
        title.setStyle("-fx-text-fill: #2C3E50;");
        Label sub = new Label("Meet the team behind Digital Vyapari");
        sub.setStyle("-fx-text-fill: #7F8C8D; -fx-font-size: 13px;");
        VBox titleBox = new VBox(2, title, sub);
        HBox bar = new HBox(titleBox);
        bar.setPadding(new Insets(16, 24, 16, 24));
        bar.setStyle(
            "-fx-background-color: white;" +
            "-fx-border-color: #E8EAED;" +
            "-fx-border-width: 0 0 1 0;" +
            "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.06), 6, 0, 0, 2);"
        );
        return bar;
    }

    private ScrollPane buildContent() {
        // ── Hero ────────────────────────────────────────────────────────────
        Label heroTitle = new Label("Digital Vyapari");
        heroTitle.setFont(Font.font("Segoe UI", FontWeight.EXTRA_BOLD, 40));
        heroTitle.setStyle("-fx-text-fill: #2C3E50;");

        Label heroSub = new Label("Connecting Farmers and Shopkeepers through Technology");
        heroSub.setFont(Font.font("Segoe UI", 17));
        heroSub.setStyle("-fx-text-fill: #7F8C8D;");
        heroSub.setWrapText(true);

        Label heroDesc = new Label(
            "Digital Vyapari is a modern digital platform designed to bridge the gap between\n" +
            "farmers/suppliers and local shopkeepers. Our system enables transparent pricing,\n" +
            "real-time inventory tracking, and seamless billing for small businesses."
        );
        heroDesc.setFont(Font.font("Segoe UI", 14));
        heroDesc.setStyle("-fx-text-fill: #5D6D7E; -fx-line-spacing: 4;");
        heroDesc.setWrapText(true);

        VBox heroCard = new VBox(12, heroTitle, heroSub, heroDesc);
        heroCard.setPadding(new Insets(30, 36, 30, 36));
        heroCard.setStyle(
            "-fx-background-color: white;" +
            "-fx-background-radius: 14;" +
            "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.09), 12, 0, 0, 4);"
        );

        // ── Features ─────────────────────────────────────────────────────────
        Label featTitle = new Label("Key Features");
        featTitle.setFont(Font.font("Segoe UI", FontWeight.BOLD, 18));
        featTitle.setStyle("-fx-text-fill: #2C3E50;");

        String[][] features = {
            {"🌾", "Farmer Management", "Record farmer/supplier data with material details and generate PDF invoices"},
            {"📦", "Inventory Tracking", "Real-time inventory with low-stock alerts and category management"},
            {"📊", "Analytics Dashboard", "Visual charts and AI insights for top sellers and slow-moving items"},
            {"🛒", "Order Management", "Shopkeepers can browse and buy materials with automatic inventory updates"},
            {"🔐", "Secure Login", "Firebase Authentication for both Vyapari and Shopkeeper roles"},
            {"📄", "PDF Invoices", "Professional invoice generation with iText PDF library"}
        };

        FlowPane featPane = new FlowPane(16, 16);
        featPane.setPrefWrapLength(900);
        for (String[] f : features) {
            VBox card = buildFeatureCard(f[0], f[1], f[2]);
            featPane.getChildren().add(card);
        }

        VBox featSection = new VBox(14, featTitle, featPane);

        // ── Teacher ───────────────────────────────────────────────────────────
        Label teacherTitle = new Label("Our Mentor");
        teacherTitle.setFont(Font.font("Segoe UI", FontWeight.BOLD, 18));
        teacherTitle.setStyle("-fx-text-fill: #2C3E50;");

        HBox teacherCard = buildPersonCard("Mr. Shashikant Bagal", "Teacher & Project Guide",
            "Assets/Images/shashi.png", "#E8F5E9", "#27AE60");

        VBox teacherSection = new VBox(14, teacherTitle, teacherCard);

        // ── Team ──────────────────────────────────────────────────────────────
        Label teamTitle = new Label("Development Team");
        teamTitle.setFont(Font.font("Segoe UI", FontWeight.BOLD, 18));
        teamTitle.setStyle("-fx-text-fill: #2C3E50;");

        FlowPane teamPane = new FlowPane(20, 20);
        teamPane.setPrefWrapLength(900);
        teamPane.getChildren().addAll(
            buildMemberCard("Siddhesh Dhumal", "Lead Developer", "Assets/Images/sid.jpg"),
            buildMemberCard("Pratik Pacharne", "Backend Dev", "Assets/Images/pratik.jpg"),
            buildMemberCard("Gaurav Kate", "UI Developer", "Assets/Images/gaurav.jpg"),
            buildMemberCard("Kiran Jathar", "Database Dev", "Assets/Images/kiran.jpg")
        );

        VBox teamSection = new VBox(14, teamTitle, teamPane);

        // ── Tech stack ────────────────────────────────────────────────────────
        Label techTitle = new Label("Technology Stack");
        techTitle.setFont(Font.font("Segoe UI", FontWeight.BOLD, 18));
        techTitle.setStyle("-fx-text-fill: #2C3E50;");

        String[] techs = {"☕ Java 17", "🎨 JavaFX 21", "🔥 Firebase Admin SDK", "📄 iText PDF", "📦 Apache POI", "🔐 Firebase Auth"};
        HBox techRow = new HBox(12);
        techRow.setWrapLength(900);
        for (String t : techs) {
            Label lbl = new Label(t);
            lbl.setPadding(new Insets(8, 16, 8, 16));
            lbl.setStyle(
                "-fx-background-color: #EBF5FB;" +
                "-fx-text-fill: #2471A3;" +
                "-fx-background-radius: 20;" +
                "-fx-font-size: 13px;" +
                "-fx-font-weight: bold;"
            );
            techRow.getChildren().add(lbl);
        }

        VBox techSection = new VBox(14, techTitle, techRow);

        // ── Layout ────────────────────────────────────────────────────────────
        VBox content = new VBox(24,
            heroCard, featSection, teacherSection, teamSection, techSection
        );
        content.setPadding(new Insets(24));

        ScrollPane scroll = new ScrollPane(content);
        scroll.setFitToWidth(true);
        scroll.setStyle("-fx-background-color: #F0F4F8; -fx-border-color: transparent;");
        return scroll;
    }

    private VBox buildFeatureCard(String icon, String title, String desc) {
        Label iconLbl = new Label(icon);
        iconLbl.setFont(Font.font(24));
        Label titleLbl = new Label(title);
        titleLbl.setFont(Font.font("Segoe UI", FontWeight.BOLD, 14));
        titleLbl.setStyle("-fx-text-fill: #2C3E50;");
        Label descLbl = new Label(desc);
        descLbl.setStyle("-fx-text-fill: #7F8C8D; -fx-font-size: 12px;");
        descLbl.setWrapText(true);
        descLbl.setMaxWidth(220);

        VBox card = new VBox(8, iconLbl, titleLbl, descLbl);
        card.setPadding(new Insets(16));
        card.setPrefWidth(240);
        card.setStyle(
            "-fx-background-color: white;" +
            "-fx-background-radius: 12;" +
            "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.08), 10, 0, 0, 3);"
        );
        return card;
    }

    private HBox buildPersonCard(String name, String role, String imgPath, String bg, String accent) {
        ImageView iv = loadImage(imgPath, 80);
        Label nameLbl = new Label(name);
        nameLbl.setFont(Font.font("Segoe UI", FontWeight.BOLD, 16));
        nameLbl.setStyle("-fx-text-fill: #2C3E50;");
        Label roleLbl = new Label(role);
        roleLbl.setStyle("-fx-text-fill: " + accent + "; -fx-font-size: 13px;");

        VBox info = new VBox(4, nameLbl, roleLbl);
        info.setAlignment(Pos.CENTER_LEFT);
        HBox card = new HBox(16, iv, info);
        card.setAlignment(Pos.CENTER_LEFT);
        card.setPadding(new Insets(16, 24, 16, 24));
        card.setStyle(
            "-fx-background-color: " + bg + ";" +
            "-fx-background-radius: 12;" +
            "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.08), 10, 0, 0, 3);"
        );
        return card;
    }

    private VBox buildMemberCard(String name, String role, String imgPath) {
        ImageView iv = loadImage(imgPath, 70);
        Label nameLbl = new Label(name);
        nameLbl.setFont(Font.font("Segoe UI", FontWeight.BOLD, 13));
        nameLbl.setStyle("-fx-text-fill: #2C3E50;");
        Label roleLbl = new Label(role);
        roleLbl.setStyle("-fx-text-fill: #7F8C8D; -fx-font-size: 12px;");

        VBox card = new VBox(8, iv, nameLbl, roleLbl);
        card.setAlignment(Pos.CENTER);
        card.setPadding(new Insets(16));
        card.setPrefWidth(160);
        card.setStyle(
            "-fx-background-color: white;" +
            "-fx-background-radius: 12;" +
            "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.08), 10, 0, 0, 3);"
        );
        return card;
    }

    private ImageView loadImage(String path, double size) {
        try {
            Image img = new Image(path, size * 2, size * 2, true, true);
            ImageView iv = new ImageView(img);
            iv.setFitWidth(size); iv.setFitHeight(size);
            iv.setPreserveRatio(true); iv.setSmooth(true);
            Circle clip = new Circle(size / 2, size / 2, size / 2);
            iv.setClip(clip);
            return iv;
        } catch (Exception e) {
            ImageView iv = new ImageView();
            iv.setFitWidth(size); iv.setFitHeight(size);
            return iv;
        }
    }
}
