package com.digitalvyapari.Controller;

import com.digitalvyapari.Utils.FirebaseUtil;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.itextpdf.text.*;
import com.itextpdf.text.pdf.*;

import java.awt.Desktop;
import java.io.File;
import java.io.FileOutputStream;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;

/**
 * FarmerController - Handles farmer data submission to Firebase
 * and PDF invoice generation.
 */
public class FarmerController {

    /**
     * Submit farmer/supplier record to Firebase Realtime Database.
     */
    public static void submitToFirebase(String name, String email, String address,
                                        String type, String material,
                                        String quantityStr, String rateStr) {
        FirebaseUtil.initialize();
        if (!FirebaseUtil.isInitialized()) {
            System.err.println("[Firebase] Submit aborted: not initialized.");
            return;
        }

        try {
            DatabaseReference ref = FirebaseDatabase.getInstance().getReference("farmer_data");
            String key = ref.push().getKey();

            double qty  = parseDoubleSafe(quantityStr);
            double rate = parseDoubleSafe(rateStr);
            double total = qty * rate;

            Map<String, Object> data = new HashMap<>();
            data.put("name",         nullIfBlank(name));
            data.put("email",        nullIfBlank(email));
            data.put("address",      nullIfBlank(address));
            data.put("materialType", nullIfBlank(type));
            data.put("material",     nullIfBlank(material));
            data.put("quantity",     qty);
            data.put("rate",         rate);
            data.put("finalPrice",   total);
            data.put("timestamp",    System.currentTimeMillis());
            data.put("status",       "active");

            ref.child(key).setValueAsync(data);
            System.out.println("[Firebase] ✅ Submitted farmer record key=" + key);

        } catch (Exception ex) {
            System.err.println("[Firebase] Error submitting farmer data:");
            ex.printStackTrace();
        }
    }

    /**
     * Generate a professional PDF invoice.
     */
    public static void generatePDF(String name, String email, String address, String type,
                                    String material, double quantity, double rate, double total) {
        try {
            String fileName = "Invoice_" + System.currentTimeMillis() + ".pdf";
            Document document = new Document(PageSize.A4, 50, 50, 70, 50);
            PdfWriter writer = PdfWriter.getInstance(document, new FileOutputStream(fileName));
            document.open();

            // Fonts
            Font titleFont   = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 22, BaseColor.WHITE);
            Font subtitleFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 12, BaseColor.WHITE);
            Font labelFont   = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 11, new BaseColor(44, 62, 80));
            Font valueFont   = FontFactory.getFont(FontFactory.HELVETICA, 11, BaseColor.BLACK);
            Font footerFont  = FontFactory.getFont(FontFactory.HELVETICA_OBLIQUE, 9, BaseColor.GRAY);
            Font totalFont   = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 13, new BaseColor(39, 174, 96));

            // ── HEADER ──────────────────────────────────────────────────────────
            PdfPTable headerTable = new PdfPTable(1);
            headerTable.setWidthPercentage(100);

            PdfPCell headerCell = new PdfPCell(new Phrase("Digital Vyapari", titleFont));
            headerCell.setBackgroundColor(new BaseColor(26, 37, 47));
            headerCell.setPadding(20);
            headerCell.setHorizontalAlignment(Element.ALIGN_CENTER);
            headerCell.setBorder(Rectangle.NO_BORDER);
            headerTable.addCell(headerCell);

            PdfPCell subCell = new PdfPCell(new Phrase("FARMER SUPPLY INVOICE", subtitleFont));
            subCell.setBackgroundColor(new BaseColor(39, 174, 96));
            subCell.setPadding(8);
            subCell.setHorizontalAlignment(Element.ALIGN_CENTER);
            subCell.setBorder(Rectangle.NO_BORDER);
            headerTable.addCell(subCell);
            document.add(headerTable);

            // ── INVOICE META ─────────────────────────────────────────────────
            document.add(Chunk.NEWLINE);
            PdfPTable metaTable = new PdfPTable(2);
            metaTable.setWidthPercentage(100);
            metaTable.setSpacingBefore(10f);

            String invoiceNo   = "INV-" + System.currentTimeMillis();
            String invoiceDate = LocalDate.now().format(DateTimeFormatter.ofPattern("dd MMMM yyyy"));

            addMetaCell(metaTable, "Invoice No: " + invoiceNo, Element.ALIGN_LEFT, labelFont);
            addMetaCell(metaTable, "Date: " + invoiceDate, Element.ALIGN_RIGHT, labelFont);
            document.add(metaTable);

            // ── DIVIDER LINE ─────────────────────────────────────────────────
            PdfPTable divider = new PdfPTable(1);
            divider.setWidthPercentage(100);
            divider.setSpacingBefore(10f);
            divider.setSpacingAfter(10f);
            PdfPCell divCell = new PdfPCell();
            divCell.setBackgroundColor(new BaseColor(39, 174, 96));
            divCell.setFixedHeight(2f);
            divCell.setBorder(Rectangle.NO_BORDER);
            divider.addCell(divCell);
            document.add(divider);

            // ── CUSTOMER DETAILS ────────────────────────────────────────────
            Paragraph custHeader = new Paragraph("SUPPLIER DETAILS", labelFont);
            custHeader.setSpacingBefore(15);
            custHeader.setSpacingAfter(8);
            document.add(custHeader);

            PdfPTable custTable = new PdfPTable(2);
            custTable.setWidthPercentage(80);
            custTable.setWidths(new float[]{2, 4});
            custTable.setSpacingAfter(15f);
            addTableRow(custTable, "Name:", name, labelFont, valueFont);
            addTableRow(custTable, "Email:", email, labelFont, valueFont);
            addTableRow(custTable, "Address:", address, labelFont, valueFont);
            document.add(custTable);

            // ── ORDER DETAILS ────────────────────────────────────────────────
            Paragraph orderHeader = new Paragraph("ORDER DETAILS", labelFont);
            orderHeader.setSpacingBefore(10);
            orderHeader.setSpacingAfter(8);
            document.add(orderHeader);

            PdfPTable orderTable = new PdfPTable(2);
            orderTable.setWidthPercentage(80);
            orderTable.setWidths(new float[]{2, 4});
            orderTable.setSpacingAfter(10f);
            addTableRow(orderTable, "Material Type:", type, labelFont, valueFont);
            addTableRow(orderTable, "Material:", material, labelFont, valueFont);
            addTableRow(orderTable, "Quantity:", String.format("%.2f kg", quantity), labelFont, valueFont);
            addTableRow(orderTable, "Rate:", String.format("\u20B9%.2f /kg", rate), labelFont, valueFont);
            document.add(orderTable);

            // ── TOTAL BOX ────────────────────────────────────────────────────
            PdfPTable totalTable = new PdfPTable(1);
            totalTable.setWidthPercentage(40);
            totalTable.setHorizontalAlignment(Element.ALIGN_RIGHT);
            totalTable.setSpacingBefore(8f);

            PdfPCell totalCell = new PdfPCell(new Phrase("TOTAL:  \u20B9" + String.format("%.2f", total), totalFont));
            totalCell.setBackgroundColor(new BaseColor(232, 246, 238));
            totalCell.setBorderColor(new BaseColor(39, 174, 96));
            totalCell.setPadding(12);
            totalCell.setHorizontalAlignment(Element.ALIGN_CENTER);
            totalTable.addCell(totalCell);
            document.add(totalTable);

            // ── FOOTER ───────────────────────────────────────────────────────
            Paragraph footer = new Paragraph("\n\nThank you for choosing Digital Vyapari!", footerFont);
            footer.setAlignment(Element.ALIGN_CENTER);
            footer.setSpacingBefore(35f);
            document.add(footer);

            document.close();

            System.out.println("[PDF] ✅ Invoice saved: " + fileName);
            File pdfFile = new File(fileName);
            if (pdfFile.exists() && Desktop.isDesktopSupported()) {
                Desktop.getDesktop().open(pdfFile);
            }

        } catch (Exception e) {
            System.err.println("[PDF] Error generating invoice:");
            e.printStackTrace();
        }
    }

    // ── Helpers ─────────────────────────────────────────────────────────────

    private static void addTableRow(PdfPTable table, String label, String value, Font lf, Font vf) {
        PdfPCell lc = new PdfPCell(new Phrase(label, lf));
        lc.setBorder(Rectangle.NO_BORDER);
        lc.setPadding(5);

        PdfPCell vc = new PdfPCell(new Phrase(value != null ? value : "-", vf));
        vc.setBorder(Rectangle.NO_BORDER);
        vc.setPadding(5);

        table.addCell(lc);
        table.addCell(vc);
    }

    private static void addMetaCell(PdfPTable table, String text, int align, Font font) {
        PdfPCell cell = new PdfPCell(new Phrase(text, font));
        cell.setBorder(Rectangle.NO_BORDER);
        cell.setHorizontalAlignment(align);
        cell.setPadding(4);
        table.addCell(cell);
    }

    private static double parseDoubleSafe(String s) {
        try { return Double.parseDouble(s.trim()); }
        catch (Exception e) { return 0.0; }
    }

    private static String nullIfBlank(String s) {
        return (s == null || s.trim().isEmpty()) ? null : s.trim();
    }
}
