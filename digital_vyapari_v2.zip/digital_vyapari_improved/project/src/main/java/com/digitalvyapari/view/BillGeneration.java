package com.digitalvyapari.view;

import javafx.application.Application;
import javafx.stage.Stage;

/** Legacy class - invoice generation now in FarmerController.generatePDF() */
public class BillGeneration extends Application {
    @Override
    public void start(Stage stage) {
        new VyapariHome().start(stage);
    }
}
