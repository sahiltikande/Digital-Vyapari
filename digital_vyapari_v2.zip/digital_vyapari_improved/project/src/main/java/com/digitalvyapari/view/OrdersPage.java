package com.digitalvyapari.view;

import com.digitalvyapari.Controller.ShopkeeperController;
import com.digitalvyapari.Controller.ShopkeeperController.Order;
import com.digitalvyapari.Utils.UIHelper;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.beans.property.*;
import javafx.collections.*;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;

public class OrdersPage extends Application {

    private final ObservableList<Order> masterData   = FXCollections.observableArrayList();
    private final ObservableList<Order> filteredData = FXCollections.observableArrayList();
    private Label countLabel;
    private TextField searchField;

    @Override
    public void start(Stage stage) {
        stage.setTitle("Digital Vyapari - Orders");

        Sidebar sidebar = new Sidebar(stage, "Orders");

        BorderPane mainArea = new BorderPane();
        mainArea.setStyle("-fx-background-color: #F0F4F8;");
        mainArea.setTop(buildTopBar(stage));
        mainArea.setCenter(buildContent());

        HBox root = new HBox(sidebar, mainArea);
        HBox.setHgrow(mainArea, Priority.ALWAYS);

        Scene scene = new Scene(root, 1400, 850);
        stage.setScene(scene);
        stage.setFullScreen(true);
        stage.show();

        loadOrders();
    }

    private HBox buildTopBar(Stage stage) {
        Label title = new Label("📋 Customer Orders");
        title.setFont(Font.font("Segoe UI", FontWeight.BOLD, 22));
        title.setStyle("-fx-text-fill: #2C3E50;");
        Label sub = new Label("Track and manage all customer orders");
        sub.setStyle("-fx-text-fill: #7F8C8D; -fx-font-size: 13px;");
        VBox titleBox = new VBox(2, title, sub);
        Region spacer = new Region(); HBox.setHgrow(spacer, Priority.ALWAYS);

        Button refreshBtn = UIHelper.outlineButton("↻  Refresh");
        refreshBtn.setOnAction(e -> loadOrders());

        Button exportBtn = UIHelper.warningButton("📥 Export CSV");
        exportBtn.setOnAction(e -> exportCSV());

        HBox bar = new HBox(16, titleBox, spacer, refreshBtn, exportBtn);
        bar.setAlignment(Pos.CENTER_LEFT);
        bar.setPadding(new Insets(16, 24, 16, 24));
        bar.setStyle(
            "-fx-background-color: white;" +
            "-fx-border-color: #E8EAED;" +
            "-fx-border-width: 0 0 1 0;" +
            "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.06), 6, 0, 0, 2);"
        );
        return bar;
    }

    private VBox buildContent() {
        // ── Filter / Search ───────────────────────────────────────────────────
        searchField = new TextField();
        searchField.setPromptText("🔍  Search orders by customer, material...");
        searchField.setPrefWidth(300);
        searchField.setStyle(
            "-fx-background-radius: 20; -fx-border-radius: 20;" +
            "-fx-border-color: #D5D8DC; -fx-padding: 8 16 8 16; -fx-font-size: 13px;"
        );
        searchField.textProperty().addListener((o, old, n) -> applyFilter());

        ComboBox<String> statusFilter = UIHelper.styledComboBox("All Status");
        statusFilter.getItems().addAll("All", "pending", "completed", "cancelled");
        statusFilter.setValue("All");
        statusFilter.setOnAction(e -> applyFilter());

        countLabel = new Label("Loading...");
        countLabel.setStyle("-fx-text-fill: #7F8C8D; -fx-font-size: 13px;");

        HBox filterBar = new HBox(12, searchField, statusFilter, countLabel);
        filterBar.setAlignment(Pos.CENTER_LEFT);
        filterBar.setPadding(new Insets(14, 20, 14, 20));
        filterBar.setStyle("-fx-background-color: white; -fx-border-color: #E8EAED; -fx-border-width: 0 0 1 0;");

        // ── Table ─────────────────────────────────────────────────────────────
        TableView<Order> table = buildTable();
        VBox.setVgrow(table, Priority.ALWAYS);

        VBox tableCard = new VBox(filterBar, table);
        tableCard.setStyle(
            "-fx-background-color: white;" +
            "-fx-background-radius: 12;" +
            "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.09), 12, 0, 0, 4);"
        );
        VBox.setVgrow(tableCard, Priority.ALWAYS);

        VBox content = new VBox(tableCard);
        content.setPadding(new Insets(20));
        VBox.setVgrow(content, Priority.ALWAYS);
        return content;
    }

    @SuppressWarnings("unchecked")
    private TableView<Order> buildTable() {
        TableView<Order> tv = new TableView<>(filteredData);
        tv.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
        tv.setPlaceholder(new Label("No orders found."));
        tv.setStyle("-fx-background-color: white; -fx-border-color: transparent;");

        TableColumn<Order, String> custCol = new TableColumn<>("Customer");
        custCol.setCellValueFactory(p -> new SimpleStringProperty(p.getValue().name));
        custCol.setStyle("-fx-font-weight: bold;");

        TableColumn<Order, String> addrCol = new TableColumn<>("Address");
        addrCol.setCellValueFactory(p -> new SimpleStringProperty(p.getValue().address));

        TableColumn<Order, String> typeCol = new TableColumn<>("Category");
        typeCol.setCellValueFactory(p -> new SimpleStringProperty(p.getValue().type));
        typeCol.setCellFactory(col -> new TableCell<>() {
            @Override protected void updateItem(String v, boolean e) {
                super.updateItem(v, e);
                if (e || v == null) { setText(""); setGraphic(null); return; }
                setGraphic(UIHelper.infoBadge(v)); setText("");
            }
        });

        TableColumn<Order, String> matCol = new TableColumn<>("Material");
        matCol.setCellValueFactory(p -> new SimpleStringProperty(capitalize(p.getValue().material)));

        TableColumn<Order, Number> qtyCol = new TableColumn<>("Qty (kg)");
        qtyCol.setCellValueFactory(p -> new SimpleIntegerProperty(p.getValue().quantity));

        TableColumn<Order, Number> rateCol = new TableColumn<>("Rate");
        rateCol.setCellValueFactory(p -> new SimpleDoubleProperty(p.getValue().rate));
        rateCol.setCellFactory(col -> new TableCell<>() {
            @Override protected void updateItem(Number v, boolean e) {
                super.updateItem(v, e);
                setText(e || v == null ? "" : "₹" + String.format("%.2f", v.doubleValue()));
            }
        });

        TableColumn<Order, Number> totalCol = new TableColumn<>("Total (₹)");
        totalCol.setCellValueFactory(p -> new SimpleDoubleProperty(p.getValue().total));
        totalCol.setCellFactory(col -> new TableCell<>() {
            @Override protected void updateItem(Number v, boolean e) {
                super.updateItem(v, e);
                setText(e || v == null ? "" : "₹" + String.format("%.2f", v.doubleValue()));
                setStyle("-fx-font-weight: bold; -fx-text-fill: #27AE60;");
            }
        });

        TableColumn<Order, String> dateCol = new TableColumn<>("Date");
        dateCol.setCellValueFactory(p -> {
            SimpleDateFormat sdf = new SimpleDateFormat("dd MMM yyyy, HH:mm");
            return new SimpleStringProperty(sdf.format(new Date(p.getValue().timestamp)));
        });

        TableColumn<Order, String> statusCol = new TableColumn<>("Status");
        statusCol.setCellValueFactory(p -> new SimpleStringProperty(p.getValue().status));
        statusCol.setCellFactory(col -> new TableCell<>() {
            @Override protected void updateItem(String v, boolean e) {
                super.updateItem(v, e);
                if (e || v == null) { setText(""); setGraphic(null); return; }
                Label badge = switch (v) {
                    case "completed" -> UIHelper.successBadge("Completed");
                    case "cancelled" -> UIHelper.dangerBadge("Cancelled");
                    default          -> UIHelper.warningBadge("Pending");
                };
                setGraphic(badge); setText("");
            }
        });

        tv.getColumns().addAll(custCol, addrCol, typeCol, matCol, qtyCol, rateCol, totalCol, dateCol, statusCol);
        tv.setRowFactory(t -> {
            TableRow<Order> row = new TableRow<>();
            row.setPrefHeight(44);
            return row;
        });
        return tv;
    }

    private void applyFilter() {
        String search = searchField != null ? searchField.getText().toLowerCase().trim() : "";
        filteredData.setAll(
            masterData.stream()
                .filter(o -> search.isEmpty()
                    || (o.name != null && o.name.toLowerCase().contains(search))
                    || (o.material != null && o.material.toLowerCase().contains(search)))
                .collect(Collectors.toList())
        );
        countLabel.setText(filteredData.size() + " orders");
    }

    private void loadOrders() {
        countLabel.setText("Loading...");
        new Thread(() -> {
            List<Order> orders = ShopkeeperController.getOrders();
            Platform.runLater(() -> {
                masterData.setAll(orders);
                applyFilter();
            });
        }).start();
    }

    private void exportCSV() {
        StringBuilder sb = new StringBuilder("Customer,Address,Category,Material,Qty,Rate,Total,Date,Status\n");
        SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy HH:mm");
        for (Order o : filteredData) {
            sb.append(String.join(",",
                safe(o.name), safe(o.address), safe(o.type), safe(o.material),
                String.valueOf(o.quantity), String.valueOf(o.rate), String.valueOf(o.total),
                sdf.format(new Date(o.timestamp)), safe(o.status)
            )).append("\n");
        }
        try {
            String fname = "orders_export_" + System.currentTimeMillis() + ".csv";
            java.nio.file.Files.writeString(java.nio.file.Path.of(fname), sb.toString());
            UIHelper.showInfo("Export Successful", "Saved as: " + fname);
        } catch (Exception e) {
            UIHelper.showError("Export Failed", e.getMessage());
        }
    }

    private String safe(String s) { return s != null ? s.replace(",", ";") : ""; }
    private String capitalize(String s) {
        if (s == null || s.isEmpty()) return s;
        return Character.toUpperCase(s.charAt(0)) + s.substring(1);
    }
}
