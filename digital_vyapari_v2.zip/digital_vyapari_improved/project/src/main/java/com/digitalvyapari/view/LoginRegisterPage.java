package com.digitalvyapari.view;

import com.digitalvyapari.Controller.LoginController;
import com.digitalvyapari.Utils.Session;
import com.digitalvyapari.Utils.UIHelper;
import javafx.animation.FadeTransition;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;
import javafx.util.Duration;

public class LoginRegisterPage {

    private final String role;

    public LoginRegisterPage(String role) {
        this.role = role;
    }

    public void start(Stage stage) {
        // ── Background ──────────────────────────────────────────────────────
        StackPane root = new StackPane();
        root.setStyle("-fx-background-color: linear-gradient(to bottom right, #0d2137, #0c3e66);");

        // ── Header ───────────────────────────────────────────────────────────
        Label appTitle = new Label("Digital Vyapari");
        appTitle.setFont(Font.font("Segoe UI", FontWeight.EXTRA_BOLD, 36));
        appTitle.setStyle("-fx-text-fill: white;");

        Label roleSubtitle = new Label(("Vyapari".equalsIgnoreCase(role) ? "🌾" : "🏪") + "  " + role + " Portal");
        roleSubtitle.setFont(Font.font("Segoe UI", FontWeight.SEMI_BOLD, 18));
        roleSubtitle.setStyle("-fx-text-fill: #48D1CC;");

        VBox header = new VBox(6, appTitle, roleSubtitle);
        header.setAlignment(Pos.CENTER);

        // ── Toggle Tabs ──────────────────────────────────────────────────────
        Button loginTab = new Button("Login");
        Button registerTab = new Button("Register");
        styleTab(loginTab, true);
        styleTab(registerTab, false);

        HBox tabs = new HBox(0, loginTab, registerTab);
        tabs.setAlignment(Pos.CENTER);

        // ── Form Panes ───────────────────────────────────────────────────────
        VBox loginPane    = buildLoginPane(stage, loginTab, registerTab);
        VBox registerPane = buildRegisterPane(stage, loginTab, registerTab);
        registerPane.setVisible(false);
        registerPane.setManaged(false);

        StackPane formStack = new StackPane(loginPane, registerPane);

        loginTab.setOnAction(e -> {
            registerPane.setVisible(false); registerPane.setManaged(false);
            loginPane.setVisible(true); loginPane.setManaged(true);
            styleTab(loginTab, true); styleTab(registerTab, false);
        });
        registerTab.setOnAction(e -> {
            loginPane.setVisible(false); loginPane.setManaged(false);
            registerPane.setVisible(true); registerPane.setManaged(true);
            FadeTransition ft = new FadeTransition(Duration.millis(300), registerPane);
            ft.setFromValue(0); ft.setToValue(1); ft.play();
            styleTab(registerTab, true); styleTab(loginTab, false);
        });

        // ── Back button ──────────────────────────────────────────────────────
        Button backBtn = new Button("← Back");
        backBtn.setStyle(
            "-fx-background-color: rgba(255,255,255,0.1);" +
            "-fx-text-fill: white;" +
            "-fx-border-color: rgba(255,255,255,0.3);" +
            "-fx-border-radius: 6;" +
            "-fx-background-radius: 6;" +
            "-fx-cursor: hand;" +
            "-fx-font-size: 13px;" +
            "-fx-padding: 7 16 7 16;"
        );
        backBtn.setOnAction(e -> new WelcomePage().start(stage));
        StackPane.setAlignment(backBtn, Pos.TOP_LEFT);
        StackPane.setMargin(backBtn, new Insets(20, 0, 0, 20));

        // ── Card ─────────────────────────────────────────────────────────────
        VBox card = new VBox(22, header, tabs, formStack);
        card.setAlignment(Pos.TOP_CENTER);
        card.setPadding(new Insets(38, 45, 38, 45));
        card.setMaxWidth(440);
        card.setStyle(
            "-fx-background-color: rgba(255,255,255,0.11);" +
            "-fx-background-radius: 20;" +
            "-fx-border-radius: 20;" +
            "-fx-border-color: rgba(255,255,255,0.18);" +
            "-fx-border-width: 1.5;" +
            "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.4), 40, 0, 0, 10);"
        );

        FadeTransition fade = new FadeTransition(Duration.millis(600), card);
        fade.setFromValue(0); fade.setToValue(1); fade.play();

        root.getChildren().addAll(card, backBtn);

        Scene scene = new Scene(root, 900, 700);
        stage.setScene(scene);
        stage.setTitle("Digital Vyapari - " + role);
        stage.setFullScreen(true);
        stage.show();
    }

    private VBox buildLoginPane(Stage stage, Button loginTab, Button registerTab) {
        TextField emailField = UIHelper.styledTextField("Email address");
        PasswordField passField = UIHelper.styledPasswordField("Password");

        Label errorLabel = new Label();
        errorLabel.setStyle("-fx-text-fill: #E74C3C; -fx-font-size: 12px;");
        errorLabel.setWrapText(true);

        Button loginBtn = new Button("Login  →");
        loginBtn.setPrefWidth(350);
        loginBtn.setPrefHeight(44);
        loginBtn.setFont(Font.font("Segoe UI", FontWeight.BOLD, 15));
        loginBtn.setStyle(
            "-fx-background-color: #27AE60;" +
            "-fx-text-fill: white;" +
            "-fx-background-radius: 10;" +
            "-fx-cursor: hand;"
        );
        loginBtn.setOnMouseEntered(e -> loginBtn.setStyle(
            "-fx-background-color: #1E8449;" + "-fx-text-fill: white;" +
            "-fx-background-radius: 10;" + "-fx-cursor: hand;"));
        loginBtn.setOnMouseExited(e -> loginBtn.setStyle(
            "-fx-background-color: #27AE60;" + "-fx-text-fill: white;" +
            "-fx-background-radius: 10;" + "-fx-cursor: hand;"));

        loginBtn.setOnAction(e -> {
            errorLabel.setText("");
            String email = emailField.getText().trim().toLowerCase();
            String pass  = passField.getText().trim();

            if (email.isEmpty() || pass.isEmpty()) {
                errorLabel.setText("Please enter email and password."); return;
            }

            loginBtn.setText("Logging in..."); loginBtn.setDisable(true);

            new Thread(() -> {
                LoginController.LoginResult result = LoginController.login(email, pass);
                javafx.application.Platform.runLater(() -> {
                    loginBtn.setText("Login  →"); loginBtn.setDisable(false);
                    if (result.isSuccess()) {
                        Session.setUser(result.uid, result.displayName, email, role);
                        if ("Vyapari".equalsIgnoreCase(role)) {
                            new VyapariHome().start(stage);
                        } else {
                            new ShopkeeperHomePage().start(stage);
                        }
                    } else {
                        errorLabel.setText(result.error);
                    }
                });
            }).start();
        });

        Label noAccount = new Label("Don't have an account?");
        noAccount.setStyle("-fx-text-fill: rgba(255,255,255,0.6); -fx-font-size: 13px;");
        Button switchToReg = new Button("Register here");
        switchToReg.setStyle(
            "-fx-background-color: transparent;" +
            "-fx-text-fill: #48D1CC;" +
            "-fx-underline: true;" +
            "-fx-cursor: hand;" +
            "-fx-font-size: 13px;"
        );
        switchToReg.setOnAction(e -> registerTab.fire());
        HBox switchRow = new HBox(6, noAccount, switchToReg);
        switchRow.setAlignment(Pos.CENTER);

        VBox pane = new VBox(14,
            styledFieldBox("Email", emailField),
            styledFieldBox("Password", passField),
            errorLabel, loginBtn, switchRow);
        pane.setAlignment(Pos.CENTER);
        return pane;
    }

    private VBox buildRegisterPane(Stage stage, Button loginTab, Button registerTab) {
        TextField nameField    = UIHelper.styledTextField("Full name");
        TextField emailField   = UIHelper.styledTextField("Email address");
        PasswordField passField = UIHelper.styledPasswordField("Password (min 6 chars)");
        PasswordField confPass  = UIHelper.styledPasswordField("Confirm password");
        TextField mobileField  = UIHelper.styledTextField("Mobile number");
        TextField addressField = UIHelper.styledTextField("Address");

        Label errorLabel = new Label();
        errorLabel.setStyle("-fx-text-fill: #E74C3C; -fx-font-size: 12px;");
        errorLabel.setWrapText(true);

        Button regBtn = new Button("Create Account  →");
        regBtn.setPrefWidth(350);
        regBtn.setPrefHeight(44);
        regBtn.setFont(Font.font("Segoe UI", FontWeight.BOLD, 15));
        regBtn.setStyle(
            "-fx-background-color: #3498DB;" +
            "-fx-text-fill: white;" +
            "-fx-background-radius: 10;" +
            "-fx-cursor: hand;"
        );

        regBtn.setOnAction(e -> {
            errorLabel.setText("");
            String name    = nameField.getText().trim();
            String email   = emailField.getText().trim().toLowerCase();
            String pass    = passField.getText().trim();
            String conf    = confPass.getText().trim();
            String mobile  = mobileField.getText().trim();
            String address = addressField.getText().trim();

            if (name.isEmpty() || email.isEmpty() || pass.isEmpty()
                    || conf.isEmpty() || mobile.isEmpty() || address.isEmpty()) {
                errorLabel.setText("All fields are required."); return;
            }
            if (!pass.equals(conf)) {
                errorLabel.setText("Passwords do not match."); return;
            }
            if (pass.length() < 6) {
                errorLabel.setText("Password must be at least 6 characters."); return;
            }

            regBtn.setText("Creating..."); regBtn.setDisable(true);

            new Thread(() -> {
                String error = LoginController.register(email, pass, name, address, mobile, role);
                javafx.application.Platform.runLater(() -> {
                    regBtn.setText("Create Account  →"); regBtn.setDisable(false);
                    if (error == null) {
                        UIHelper.showInfo("Registration Successful",
                            "Welcome, " + name + "! You can now login.");
                        loginTab.fire();
                    } else {
                        errorLabel.setText(error);
                    }
                });
            }).start();
        });

        Label hasAccount = new Label("Already have an account?");
        hasAccount.setStyle("-fx-text-fill: rgba(255,255,255,0.6); -fx-font-size: 13px;");
        Button switchToLogin = new Button("Login here");
        switchToLogin.setStyle(
            "-fx-background-color: transparent;" +
            "-fx-text-fill: #48D1CC;" +
            "-fx-underline: true;" +
            "-fx-cursor: hand;" +
            "-fx-font-size: 13px;"
        );
        switchToLogin.setOnAction(e -> loginTab.fire());
        HBox switchRow = new HBox(6, hasAccount, switchToLogin);
        switchRow.setAlignment(Pos.CENTER);

        ScrollPane scroll = new ScrollPane();
        VBox inner = new VBox(12,
            styledFieldBox("Full Name", nameField),
            styledFieldBox("Email", emailField),
            styledFieldBox("Password", passField),
            styledFieldBox("Confirm Password", confPass),
            styledFieldBox("Mobile", mobileField),
            styledFieldBox("Address", addressField),
            errorLabel, regBtn, switchRow);
        inner.setAlignment(Pos.CENTER);
        inner.setPadding(new Insets(0, 2, 0, 2));
        scroll.setContent(inner);
        scroll.setFitToWidth(true);
        scroll.setMaxHeight(420);
        scroll.setStyle("-fx-background-color: transparent; -fx-border-color: transparent;");
        scroll.getStyleClass().add("transparent-scroll");

        VBox pane = new VBox(scroll);
        pane.setAlignment(Pos.CENTER);
        return pane;
    }

    private VBox styledFieldBox(String labelText, TextField field) {
        Label lbl = new Label(labelText);
        lbl.setStyle("-fx-text-fill: rgba(255,255,255,0.75); -fx-font-size: 12px; -fx-font-weight: bold;");
        field.setPrefWidth(350);
        VBox box = new VBox(5, lbl, field);
        return box;
    }

    private void styleTab(Button btn, boolean active) {
        if (active) {
            btn.setStyle(
                "-fx-background-color: #27AE60;" +
                "-fx-text-fill: white;" +
                "-fx-font-weight: bold;" +
                "-fx-cursor: hand;" +
                "-fx-font-size: 14px;" +
                "-fx-padding: 10 40 10 40;" +
                "-fx-background-radius: 0;"
            );
        } else {
            btn.setStyle(
                "-fx-background-color: rgba(255,255,255,0.1);" +
                "-fx-text-fill: rgba(255,255,255,0.6);" +
                "-fx-cursor: hand;" +
                "-fx-font-size: 14px;" +
                "-fx-padding: 10 40 10 40;" +
                "-fx-background-radius: 0;"
            );
        }
    }
}
