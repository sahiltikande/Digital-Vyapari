package com.digitalvyapari.view;

import com.digitalvyapari.Controller.MaterialController;
import com.digitalvyapari.Controller.MaterialController.MaterialEntry;
import com.digitalvyapari.Utils.Session;
import com.digitalvyapari.Utils.UIHelper;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.chart.*;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

import java.text.NumberFormat;
import java.util.*;

public class VyapariHome extends Application {

    private Label totalValueLbl  = new Label("Loading...");
    private Label totalQtyLbl    = new Label("Loading...");
    private Label lowStockLbl    = new Label("Loading...");
    private Label totalTypesLbl  = new Label("Loading...");
    private VBox  insightsBox    = new VBox(8);
    private VBox  lowStockBox    = new VBox(8);
    private BarChart<String, Number> barChart;
    private PieChart pieChart;

    @Override
    public void start(Stage stage) {
        stage.setTitle("Digital Vyapari - Dashboard");

        // ── Layout ────────────────────────────────────────────────────────────
        Sidebar sidebar = new Sidebar(stage, "Dashboard");

        BorderPane mainArea = new BorderPane();
        mainArea.setStyle("-fx-background-color: #F0F4F8;");
        mainArea.setTop(buildTopBar(stage));
        mainArea.setCenter(buildContent(stage));

        HBox root = new HBox(sidebar, mainArea);
        HBox.setHgrow(mainArea, Priority.ALWAYS);

        Scene scene = new Scene(root, 1400, 850);
        stage.setScene(scene);
        stage.setFullScreen(true);
        stage.show();

        // Load data in background
        loadDashboardData();
    }

    // ── Top Bar ───────────────────────────────────────────────────────────────

    private HBox buildTopBar(Stage stage) {
        Label pageTitle = new Label("📊 Dashboard");
        pageTitle.setFont(Font.font("Segoe UI", FontWeight.BOLD, 22));
        pageTitle.setStyle("-fx-text-fill: #2C3E50;");

        Label greet = new Label("Welcome back, " + Session.getCurrentUserName() + " 👋");
        greet.setStyle("-fx-text-fill: #7F8C8D; -fx-font-size: 13px;");

        VBox titleBox = new VBox(2, pageTitle, greet);

        Region spacer = new Region(); HBox.setHgrow(spacer, Priority.ALWAYS);

        Button refreshBtn = UIHelper.outlineButton("↻  Refresh");
        refreshBtn.setOnAction(e -> loadDashboardData());

        Button farmerBtn = UIHelper.primaryButton("+ Add Farmer Entry");
        farmerBtn.setOnAction(e -> new Farmer().start(stage));

        HBox topBar = new HBox(16, titleBox, spacer, refreshBtn, farmerBtn);
        topBar.setAlignment(Pos.CENTER_LEFT);
        topBar.setPadding(new Insets(16, 24, 16, 24));
        topBar.setStyle(
            "-fx-background-color: white;" +
            "-fx-border-color: #E8EAED;" +
            "-fx-border-width: 0 0 1 0;" +
            "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.06), 6, 0, 0, 2);"
        );
        return topBar;
    }

    // ── Content ────────────────────────────────────────────────────────────────

    private ScrollPane buildContent(Stage stage) {
        // ── Stat Cards ────────────────────────────────────────────────────────
        styleStatLabel(totalValueLbl);
        styleStatLabel(totalQtyLbl);
        styleStatLabel(lowStockLbl);
        styleStatLabel(totalTypesLbl);

        VBox card1 = buildStatCard("💰 Total Inventory Value", totalValueLbl, "#27AE60");
        VBox card2 = buildStatCard("⚖️ Total Quantity (kg)", totalQtyLbl, "#3498DB");
        VBox card3 = buildStatCard("⚠️ Low Stock Items", lowStockLbl, "#E67E22");
        VBox card4 = buildStatCard("🏷️ Material Categories", totalTypesLbl, "#9B59B6");

        HBox statsRow = new HBox(16, card1, card2, card3, card4);
        statsRow.setPadding(new Insets(0));
        for (VBox c : new VBox[]{card1, card2, card3, card4}) {
            HBox.setHgrow(c, Priority.ALWAYS);
        }

        // ── Charts ────────────────────────────────────────────────────────────
        barChart = buildBarChart();
        pieChart = buildPieChart();

        HBox chartsRow = new HBox(16, barChart, pieChart);
        HBox.setHgrow(barChart, Priority.ALWAYS);
        HBox.setHgrow(pieChart, Priority.ALWAYS);

        // ── AI Insights ───────────────────────────────────────────────────────
        VBox insightsCard = buildInsightsCard(stage);
        VBox lowStockCard = buildLowStockCard();

        HBox bottomRow = new HBox(16, insightsCard, lowStockCard);
        HBox.setHgrow(insightsCard, Priority.ALWAYS);
        HBox.setHgrow(lowStockCard, Priority.ALWAYS);

        // ── Quick Actions ─────────────────────────────────────────────────────
        HBox quickActions = buildQuickActions(stage);

        VBox content = new VBox(20, statsRow, quickActions, chartsRow, bottomRow);
        content.setPadding(new Insets(24));

        ScrollPane scroll = new ScrollPane(content);
        scroll.setFitToWidth(true);
        scroll.setStyle("-fx-background-color: #F0F4F8; -fx-border-color: transparent;");
        return scroll;
    }

    private VBox buildStatCard(String title, Label valueLbl, String color) {
        Label titleLbl = new Label(title);
        titleLbl.setStyle("-fx-text-fill: white; -fx-font-size: 13px;");

        VBox card = new VBox(6, valueLbl, titleLbl);
        card.setPadding(new Insets(20, 22, 20, 22));
        card.setAlignment(Pos.CENTER_LEFT);
        card.setStyle(
            "-fx-background-color: " + color + ";" +
            "-fx-background-radius: 12;" +
            "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.14), 12, 0, 0, 3);"
        );
        return card;
    }

    private void styleStatLabel(Label lbl) {
        lbl.setFont(Font.font("Segoe UI", FontWeight.BOLD, 26));
        lbl.setStyle("-fx-text-fill: white;");
    }

    private HBox buildQuickActions(Stage stage) {
        Label title = new Label("Quick Actions");
        title.setFont(Font.font("Segoe UI", FontWeight.BOLD, 15));
        title.setStyle("-fx-text-fill: #2C3E50;");

        Button b1 = UIHelper.primaryButton("🌾 Add Farmer");
        Button b2 = UIHelper.secondaryButton("📦 View Materials");
        Button b3 = UIHelper.warningButton("📊 Analytics");
        Button b4 = UIHelper.outlineButton("👥 About Us");

        b1.setOnAction(e -> new Farmer().start(stage));
        b2.setOnAction(e -> new MaterialsView().start(stage));
        b3.setOnAction(e -> new AnalyticsView().start(stage));
        b4.setOnAction(e -> new AboutUs().start(stage));

        HBox buttons = new HBox(12, b1, b2, b3, b4);
        buttons.setAlignment(Pos.CENTER_LEFT);

        VBox card = new VBox(12, title, buttons);
        card.setPadding(new Insets(18, 20, 18, 20));
        card.setStyle(
            "-fx-background-color: white;" +
            "-fx-background-radius: 12;" +
            "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.08), 10, 0, 0, 3);"
        );
        return new HBox(card);
    }

    private BarChart<String, Number> buildBarChart() {
        CategoryAxis xAxis = new CategoryAxis();
        NumberAxis yAxis = new NumberAxis();
        xAxis.setLabel("Material Type");
        yAxis.setLabel("Quantity (kg)");

        BarChart<String, Number> chart = new BarChart<>(xAxis, yAxis);
        chart.setTitle("📦 Inventory by Category");
        chart.setAnimated(true);
        chart.setLegendVisible(false);
        chart.setPrefHeight(280);
        chart.setStyle(
            "-fx-background-color: white;" +
            "-fx-background-radius: 12;"
        );
        return chart;
    }

    private PieChart buildPieChart() {
        PieChart chart = new PieChart();
        chart.setTitle("🥧 Distribution by Type");
        chart.setLabelsVisible(true);
        chart.setLegendVisible(true);
        chart.setAnimated(true);
        chart.setPrefHeight(280);
        chart.setStyle(
            "-fx-background-color: white;" +
            "-fx-background-radius: 12;"
        );
        return chart;
    }

    private VBox buildInsightsCard(Stage stage) {
        Label title = new Label("🤖 AI Insights");
        title.setFont(Font.font("Segoe UI", FontWeight.BOLD, 15));
        title.setStyle("-fx-text-fill: #2C3E50;");

        insightsBox.getChildren().add(new Label("Loading insights..."));

        Button viewAll = UIHelper.outlineButton("View Analytics →");
        viewAll.setOnAction(e -> new AnalyticsView().start(stage));

        VBox card = new VBox(12, title, new Separator(), insightsBox, viewAll);
        card.setPadding(new Insets(18, 20, 18, 20));
        card.setStyle(
            "-fx-background-color: white;" +
            "-fx-background-radius: 12;" +
            "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.08), 10, 0, 0, 3);"
        );
        return card;
    }

    private VBox buildLowStockCard() {
        Label title = new Label("⚠️ Low Stock Alerts");
        title.setFont(Font.font("Segoe UI", FontWeight.BOLD, 15));
        title.setStyle("-fx-text-fill: #2C3E50;");

        lowStockBox.getChildren().add(new Label("Loading..."));

        VBox card = new VBox(12, title, new Separator(), lowStockBox);
        card.setPadding(new Insets(18, 20, 18, 20));
        card.setStyle(
            "-fx-background-color: white;" +
            "-fx-background-radius: 12;" +
            "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.08), 10, 0, 0, 3);"
        );
        return card;
    }

    // ── Data Loading ──────────────────────────────────────────────────────────

    private void loadDashboardData() {
        new Thread(() -> {
            List<MaterialEntry> entries = MaterialController.getMaterialData();
            Map<String, Object> stats   = MaterialController.getDashboardStats(entries);
            List<MaterialEntry> topSellers = MaterialController.getTopSellers(entries);
            List<MaterialEntry> lowStock   = MaterialController.getLowStockItems(entries);
            Map<String, Double> byType     = MaterialController.getQuantityByType(entries);

            Platform.runLater(() -> {
                // Update stat cards
                NumberFormat fmt = NumberFormat.getInstance();
                double totalVal = (double) stats.get("totalValue");
                double totalQty = (double) stats.get("totalQuantity");
                long lowCount   = (long)   stats.get("lowStockCount");
                long typesCount = (long)   stats.get("typesCount");

                totalValueLbl.setText("₹" + fmt.format((long) totalVal));
                totalQtyLbl.setText(fmt.format((long) totalQty) + " kg");
                lowStockLbl.setText(String.valueOf(lowCount));
                totalTypesLbl.setText(String.valueOf(typesCount));

                // Update bar chart
                XYChart.Series<String, Number> series = new XYChart.Series<>();
                series.setName("Quantity");
                byType.forEach((type, qty) -> series.getData().add(
                    new XYChart.Data<>(type, qty)
                ));
                barChart.getData().clear();
                barChart.getData().add(series);

                // Update pie chart
                javafx.collections.ObservableList<PieChart.Data> pieData =
                    javafx.collections.FXCollections.observableArrayList();
                byType.forEach((type, qty) -> pieData.add(new PieChart.Data(type, qty)));
                pieChart.setData(pieData);

                // AI Insights
                insightsBox.getChildren().clear();
                if (topSellers.isEmpty()) {
                    insightsBox.getChildren().add(new Label("No data available yet."));
                } else {
                    insightsBox.getChildren().add(insightLabel("🏆 Top Seller: "
                        + topSellers.get(0).getMaterial()
                        + " (" + (int) topSellers.get(0).getQuantity() + " kg)", "#27AE60"));

                    if (topSellers.size() >= 3) {
                        insightsBox.getChildren().add(insightLabel("📈 Most stocked type: "
                            + topSellers.get(0).getType(), "#3498DB"));
                    }

                    // Total revenue
                    insightsBox.getChildren().add(insightLabel("💰 Total inventory value: ₹"
                        + fmt.format((long) totalVal), "#9B59B6"));

                    // Slow movers
                    List<MaterialEntry> slow = MaterialController.getSlowMovers(entries);
                    if (!slow.isEmpty()) {
                        insightsBox.getChildren().add(insightLabel("🐢 Slow mover: "
                            + slow.get(0).getMaterial()
                            + " (" + (int) slow.get(0).getQuantity() + " kg)", "#E67E22"));
                    }
                }

                // Low stock alerts
                lowStockBox.getChildren().clear();
                if (lowStock.isEmpty()) {
                    Label ok = new Label("✅ All items sufficiently stocked");
                    ok.setStyle("-fx-text-fill: #27AE60; -fx-font-size: 13px;");
                    lowStockBox.getChildren().add(ok);
                } else {
                    for (MaterialEntry item : lowStock) {
                        HBox row = new HBox(10);
                        row.setAlignment(Pos.CENTER_LEFT);
                        row.setPadding(new Insets(8, 12, 8, 12));
                        row.setStyle(
                            "-fx-background-color: #FEF9E7;" +
                            "-fx-background-radius: 8;"
                        );
                        Label name = new Label(item.getMaterial());
                        name.setFont(Font.font("Segoe UI", FontWeight.SEMI_BOLD, 13));
                        Region sp = new Region(); HBox.setHgrow(sp, Priority.ALWAYS);
                        Label qty = UIHelper.dangerBadge((int) item.getQuantity() + " kg");
                        row.getChildren().addAll(name, sp, qty);
                        lowStockBox.getChildren().add(row);
                    }
                }
            });
        }).start();
    }

    private Label insightLabel(String text, String color) {
        Label lbl = new Label(text);
        lbl.setWrapText(true);
        lbl.setPadding(new Insets(8, 12, 8, 12));
        lbl.setStyle(
            "-fx-background-color: derive(" + color + ", 90%);" +
            "-fx-text-fill: " + color + ";" +
            "-fx-background-radius: 8;" +
            "-fx-font-size: 13px;" +
            "-fx-font-weight: bold;"
        );
        return lbl;
    }
}
