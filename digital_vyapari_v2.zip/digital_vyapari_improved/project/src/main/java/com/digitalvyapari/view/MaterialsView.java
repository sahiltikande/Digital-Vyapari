package com.digitalvyapari.view;

import com.digitalvyapari.Controller.MaterialController;
import com.digitalvyapari.Controller.MaterialController.MaterialEntry;
import com.digitalvyapari.Utils.UIHelper;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.beans.property.*;
import javafx.collections.*;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

import java.util.List;
import java.util.stream.Collectors;

public class MaterialsView extends Application {

    private final ObservableList<MaterialEntry> masterData  = FXCollections.observableArrayList();
    private final ObservableList<MaterialEntry> filteredData = FXCollections.observableArrayList();
    private TableView<MaterialEntry> table;
    private TextField searchField;
    private ComboBox<String> typeFilter;
    private Label countLabel;

    @Override
    public void start(Stage stage) {
        stage.setTitle("Digital Vyapari - Materials");

        Sidebar sidebar = new Sidebar(stage, "Materials");

        BorderPane mainArea = new BorderPane();
        mainArea.setStyle("-fx-background-color: #F0F4F8;");
        mainArea.setTop(buildTopBar(stage));
        mainArea.setCenter(buildContent(stage));

        HBox root = new HBox(sidebar, mainArea);
        HBox.setHgrow(mainArea, Priority.ALWAYS);

        Scene scene = new Scene(root, 1400, 850);
        stage.setScene(scene);
        stage.setFullScreen(true);
        stage.show();

        loadData();
    }

    private HBox buildTopBar(Stage stage) {
        Label title = new Label("📦 Materials Inventory");
        title.setFont(Font.font("Segoe UI", FontWeight.BOLD, 22));
        title.setStyle("-fx-text-fill: #2C3E50;");

        Label sub = new Label("View and search all farmer-supplied materials");
        sub.setStyle("-fx-text-fill: #7F8C8D; -fx-font-size: 13px;");

        VBox titleBox = new VBox(2, title, sub);
        Region spacer = new Region(); HBox.setHgrow(spacer, Priority.ALWAYS);

        Button refreshBtn = UIHelper.outlineButton("↻  Refresh");
        refreshBtn.setOnAction(e -> loadData());

        Button addBtn = UIHelper.primaryButton("+ Add Farmer Entry");
        addBtn.setOnAction(e -> new Farmer().start(stage));

        HBox bar = new HBox(16, titleBox, spacer, refreshBtn, addBtn);
        bar.setAlignment(Pos.CENTER_LEFT);
        bar.setPadding(new Insets(16, 24, 16, 24));
        bar.setStyle(
            "-fx-background-color: white;" +
            "-fx-border-color: #E8EAED;" +
            "-fx-border-width: 0 0 1 0;" +
            "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.06), 6, 0, 0, 2);"
        );
        return bar;
    }

    private VBox buildContent(Stage stage) {
        // ── Search & Filter Bar ───────────────────────────────────────────────
        searchField = new TextField();
        searchField.setPromptText("🔍  Search by material, type, farmer...");
        searchField.setPrefWidth(300);
        searchField.setStyle(
            "-fx-background-radius: 20;" +
            "-fx-border-radius: 20;" +
            "-fx-border-color: #D5D8DC;" +
            "-fx-padding: 8 16 8 16;" +
            "-fx-font-size: 13px;" +
            "-fx-pref-height: 38px;"
        );
        searchField.textProperty().addListener((o, old, val) -> applyFilters());

        typeFilter = UIHelper.styledComboBox("All Categories");
        typeFilter.getItems().addAll("All", "Vegetables", "Fruits", "Sprouts", "Grains", "Dairy", "Spices", "Other");
        typeFilter.setValue("All");
        typeFilter.setPrefWidth(180);
        typeFilter.setOnAction(e -> applyFilters());

        ComboBox<String> sortBy = UIHelper.styledComboBox("Sort by...");
        sortBy.getItems().addAll("Name A-Z", "Qty High-Low", "Rate High-Low", "Value High-Low", "Newest First");
        sortBy.setValue("Name A-Z");
        sortBy.setPrefWidth(160);
        sortBy.setOnAction(e -> applySorting(sortBy.getValue()));

        countLabel = new Label("0 records");
        countLabel.setStyle("-fx-text-fill: #7F8C8D; -fx-font-size: 13px;");

        Region spacer = new Region(); HBox.setHgrow(spacer, Priority.ALWAYS);

        Button exportBtn = UIHelper.warningButton("📥 Export CSV");
        exportBtn.setOnAction(e -> exportToCSV());

        HBox filterBar = new HBox(12, searchField, typeFilter, sortBy, spacer, countLabel, exportBtn);
        filterBar.setAlignment(Pos.CENTER_LEFT);
        filterBar.setPadding(new Insets(16, 20, 12, 20));
        filterBar.setStyle("-fx-background-color: white; -fx-border-color: #E8EAED; -fx-border-width: 0 0 1 0;");

        // ── Table ─────────────────────────────────────────────────────────────
        table = buildTable();

        VBox tableCard = new VBox(filterBar, table);
        tableCard.setStyle(
            "-fx-background-color: white;" +
            "-fx-background-radius: 12;" +
            "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.09), 12, 0, 0, 4);"
        );
        VBox.setVgrow(table, Priority.ALWAYS);

        VBox content = new VBox(tableCard);
        content.setPadding(new Insets(20));
        VBox.setVgrow(tableCard, Priority.ALWAYS);
        return content;
    }

    @SuppressWarnings("unchecked")
    private TableView<MaterialEntry> buildTable() {
        TableView<MaterialEntry> tv = new TableView<>(filteredData);
        tv.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
        tv.setPlaceholder(new Label("No materials found. Add a farmer entry to get started."));
        tv.setStyle("-fx-background-color: white; -fx-border-color: transparent;");

        TableColumn<MaterialEntry, String> typeCol = new TableColumn<>("Category");
        typeCol.setCellValueFactory(p -> new SimpleStringProperty(p.getValue().getType()));
        typeCol.setCellFactory(col -> categoryCell());

        TableColumn<MaterialEntry, String> matCol = new TableColumn<>("Material");
        matCol.setCellValueFactory(p -> new SimpleStringProperty(capitalize(p.getValue().getMaterial())));
        matCol.setStyle("-fx-font-weight: bold;");

        TableColumn<MaterialEntry, String> farmerCol = new TableColumn<>("Farmer");
        farmerCol.setCellValueFactory(p -> new SimpleStringProperty(p.getValue().getFarmerName()));

        TableColumn<MaterialEntry, Number> qtyCol = new TableColumn<>("Quantity (kg)");
        qtyCol.setCellValueFactory(p -> new SimpleDoubleProperty(p.getValue().getQuantity()));
        qtyCol.setCellFactory(col -> stockCell());

        TableColumn<MaterialEntry, Number> rateCol = new TableColumn<>("Rate (₹/kg)");
        rateCol.setCellValueFactory(p -> new SimpleDoubleProperty(p.getValue().getRate()));
        rateCol.setCellFactory(col -> new TableCell<>() {
            @Override protected void updateItem(Number val, boolean empty) {
                super.updateItem(val, empty);
                setText(empty || val == null ? "" : "₹" + String.format("%.2f", val.doubleValue()));
            }
        });

        TableColumn<MaterialEntry, Number> valueCol = new TableColumn<>("Total Value (₹)");
        valueCol.setCellValueFactory(p -> new SimpleDoubleProperty(p.getValue().getFinalPrice()));
        valueCol.setCellFactory(col -> new TableCell<>() {
            @Override protected void updateItem(Number val, boolean empty) {
                super.updateItem(val, empty);
                setText(empty || val == null ? "" : "₹" + String.format("%.2f", val.doubleValue()));
                setStyle("-fx-font-weight: bold; -fx-text-fill: #27AE60;");
            }
        });

        TableColumn<MaterialEntry, String> statusCol = new TableColumn<>("Stock Status");
        statusCol.setCellValueFactory(p ->
            new SimpleStringProperty(p.getValue().isLowStock() ? "Low Stock" : "In Stock"));
        statusCol.setCellFactory(col -> new TableCell<>() {
            @Override protected void updateItem(String val, boolean empty) {
                super.updateItem(val, empty);
                if (empty || val == null) { setText(""); setGraphic(null); return; }
                Label badge = "Low Stock".equals(val) ? UIHelper.dangerBadge(val) : UIHelper.successBadge(val);
                setGraphic(badge); setText("");
            }
        });

        tv.getColumns().addAll(typeCol, matCol, farmerCol, qtyCol, rateCol, valueCol, statusCol);
        tv.setRowFactory(t -> {
            TableRow<MaterialEntry> row = new TableRow<>();
            row.setPrefHeight(44);
            return row;
        });
        return tv;
    }

    private TableCell<MaterialEntry, String> categoryCell() {
        return new TableCell<>() {
            @Override protected void updateItem(String val, boolean empty) {
                super.updateItem(val, empty);
                if (empty || val == null) { setText(""); setGraphic(null); return; }
                Label lbl = UIHelper.infoBadge(val);
                setGraphic(lbl); setText("");
            }
        };
    }

    private TableCell<MaterialEntry, Number> stockCell() {
        return new TableCell<>() {
            @Override protected void updateItem(Number val, boolean empty) {
                super.updateItem(val, empty);
                if (empty || val == null) { setText(""); return; }
                double qty = val.doubleValue();
                setText(String.format("%.1f", qty));
                if (qty < 10) setStyle("-fx-text-fill: #E74C3C; -fx-font-weight: bold;");
                else if (qty < 50) setStyle("-fx-text-fill: #E67E22;");
                else setStyle("-fx-text-fill: #27AE60; -fx-font-weight: bold;");
            }
        };
    }

    private void applyFilters() {
        String search = searchField.getText().toLowerCase().trim();
        String type   = typeFilter.getValue();
        if (type == null || type.equals("All")) type = "";
        final String filterType = type;

        List<MaterialEntry> filtered = masterData.stream()
            .filter(e -> search.isEmpty()
                || e.getMaterial().toLowerCase().contains(search)
                || e.getType().toLowerCase().contains(search)
                || e.getFarmerName().toLowerCase().contains(search))
            .filter(e -> filterType.isEmpty() || e.getType().equals(filterType))
            .collect(Collectors.toList());

        filteredData.setAll(filtered);
        countLabel.setText(filtered.size() + " records");
    }

    private void applySorting(String mode) {
        if (mode == null) return;
        switch (mode) {
            case "Name A-Z":      filteredData.sort((a, b) -> a.getMaterial().compareTo(b.getMaterial())); break;
            case "Qty High-Low":  filteredData.sort((a, b) -> Double.compare(b.getQuantity(), a.getQuantity())); break;
            case "Rate High-Low": filteredData.sort((a, b) -> Double.compare(b.getRate(), a.getRate())); break;
            case "Value High-Low":filteredData.sort((a, b) -> Double.compare(b.getFinalPrice(), a.getFinalPrice())); break;
            case "Newest First":  filteredData.sort((a, b) -> Long.compare(b.getTimestamp(), a.getTimestamp())); break;
        }
    }

    private void loadData() {
        countLabel.setText("Loading...");
        new Thread(() -> {
            List<MaterialEntry> data = MaterialController.getMaterialData();
            Platform.runLater(() -> {
                masterData.setAll(data);
                applyFilters();
            });
        }).start();
    }

    private void exportToCSV() {
        StringBuilder sb = new StringBuilder("Type,Material,Farmer,Quantity,Rate,Total Value\n");
        for (MaterialEntry e : filteredData) {
            sb.append(String.join(",",
                e.getType(), capitalize(e.getMaterial()), e.getFarmerName(),
                String.valueOf(e.getQuantity()), String.valueOf(e.getRate()),
                String.valueOf(e.getFinalPrice())
            )).append("\n");
        }
        try {
            String fileName = "materials_export_" + System.currentTimeMillis() + ".csv";
            java.nio.file.Files.writeString(java.nio.file.Path.of(fileName), sb.toString());
            UIHelper.showInfo("Export Successful", "Saved as: " + fileName);
        } catch (Exception ex) {
            UIHelper.showError("Export Failed", ex.getMessage());
        }
    }

    private String capitalize(String s) {
        if (s == null || s.isEmpty()) return s;
        return Character.toUpperCase(s.charAt(0)) + s.substring(1);
    }
}
