package com.digitalvyapari.Controller;

import com.digitalvyapari.Utils.FirebaseUtil;
import com.google.firebase.database.*;

import java.util.*;
import java.util.concurrent.CountDownLatch;

/**
 * ShopkeeperController - Manages orders, posts, and buy requests.
 */
public class ShopkeeperController {

    public static class Order {
        public String key;
        public String name;
        public String address;
        public String material;
        public String type;
        public int quantity;
        public double rate;
        public double total;
        public long timestamp;
        public String status;

        public Order(String key, String name, String address, String material,
                     String type, int quantity, double rate, long timestamp, String status) {
            this.key = key;
            this.name = name;
            this.address = address;
            this.material = material;
            this.type = type;
            this.quantity = quantity;
            this.rate = rate;
            this.total = quantity * rate;
            this.timestamp = timestamp;
            this.status = status != null ? status : "pending";
        }
    }

    /** Place an order in Firebase */
    public static void placeOrder(String customerName, String address,
                                   MaterialController.MaterialEntry entry, int qty) {
        FirebaseUtil.initialize();
        DatabaseReference orderRef = FirebaseDatabase.getInstance().getReference("orders").push();

        Map<String, Object> order = new HashMap<>();
        order.put("name", customerName);
        order.put("address", address);
        order.put("material", entry.getMaterial());
        order.put("type", entry.getType());
        order.put("quantity", qty);
        order.put("rate", entry.getRate());
        order.put("total", qty * entry.getRate());
        order.put("timestamp", System.currentTimeMillis());
        order.put("status", "pending");

        orderRef.setValueAsync(order);
    }

    /** Fetch all orders (one-time) */
    public static List<Order> getOrders() {
        FirebaseUtil.initialize();
        List<Order> orders = new ArrayList<>();

        if (!FirebaseUtil.isInitialized()) return orders;

        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("orders");
        CountDownLatch latch = new CountDownLatch(1);

        ref.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                for (DataSnapshot child : snapshot.getChildren()) {
                    try {
                        String name     = child.child("name").getValue(String.class);
                        String address  = child.child("address").getValue(String.class);
                        String material = child.child("material").getValue(String.class);
                        String type     = child.child("type").getValue(String.class);
                        String status   = child.child("status").getValue(String.class);
                        Long qtyL = child.child("quantity").getValue(Long.class);
                        Long tsL  = child.child("timestamp").getValue(Long.class);
                        Double rateD = child.child("rate").getValue(Double.class);
                        if (rateD == null) {
                            Long rl = child.child("rate").getValue(Long.class);
                            rateD = rl != null ? rl.doubleValue() : 0.0;
                        }

                        orders.add(new Order(
                                child.getKey(), name, address, material, type,
                                qtyL != null ? qtyL.intValue() : 0,
                                rateD, tsL != null ? tsL : 0L, status
                        ));
                    } catch (Exception e) {
                        System.err.println("[Order] Error parsing: " + e.getMessage());
                    }
                }
                // Sort newest first
                orders.sort(Comparator.comparingLong((Order o) -> o.timestamp).reversed());
                latch.countDown();
            }

            @Override
            public void onCancelled(DatabaseError error) {
                System.err.println("[Order] Fetch cancelled: " + error.getMessage());
                latch.countDown();
            }
        });

        try { latch.await(); }
        catch (InterruptedException e) { Thread.currentThread().interrupt(); }

        return orders;
    }

    /** Update order status */
    public static void updateOrderStatus(String orderKey, String status) {
        FirebaseUtil.initialize();
        FirebaseDatabase.getInstance()
                .getReference("orders")
                .child(orderKey)
                .child("status")
                .setValueAsync(status);
    }

    /** Update inventory after an order is placed */
    public static void updateInventoryQuantity(MaterialController.MaterialEntry entry, int orderedQty) {
        FirebaseUtil.initialize();
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("farmer_data");

        ref.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                for (DataSnapshot child : snapshot.getChildren()) {
                    String type     = child.child("materialType").getValue(String.class);
                    String material = child.child("material").getValue(String.class);
                    Double rateD    = child.child("rate").getValue(Double.class);
                    if (rateD == null) {
                        Long rl = child.child("rate").getValue(Long.class);
                        rateD = rl != null ? rl.doubleValue() : 0.0;
                    }
                    Double qtyD = child.child("quantity").getValue(Double.class);
                    if (qtyD == null) {
                        Long ql = child.child("quantity").getValue(Long.class);
                        qtyD = ql != null ? ql.doubleValue() : 0.0;
                    }

                    if (type != null && material != null
                            && type.equals(entry.getType())
                            && material.equals(entry.getMaterial())
                            && Math.abs(rateD - entry.getRate()) < 0.01) {

                        double updated = qtyD - orderedQty;
                        if (updated <= 0) {
                            child.getRef().removeValueAsync();
                        } else {
                            child.getRef().child("quantity").setValueAsync(updated);
                        }
                    }
                }
            }

            @Override
            public void onCancelled(DatabaseError error) {
                System.err.println("[Inventory] Update cancelled: " + error.getMessage());
            }
        });
    }
}
