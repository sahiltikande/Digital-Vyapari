package com.digitalvyapari.Utils;

import javafx.animation.FadeTransition;
import javafx.animation.ScaleTransition;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.effect.DropShadow;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.util.Duration;

/**
 * UIHelper - Centralized factory for styled UI components.
 * Ensures consistent look & feel across all screens.
 */
public class UIHelper {

    // ── COLOR PALETTE ──────────────────────────────────────────────────────────
    public static final String GREEN      = "#27AE60";
    public static final String GREEN_DARK = "#1E8449";
    public static final String BLUE       = "#3498DB";
    public static final String BLUE_DARK  = "#2980B9";
    public static final String RED        = "#E74C3C";
    public static final String RED_DARK   = "#C0392B";
    public static final String ORANGE     = "#F39C12";
    public static final String PURPLE     = "#9B59B6";
    public static final String DARK_BG    = "#1A252F";
    public static final String CARD_BG    = "#FFFFFF";
    public static final String PAGE_BG    = "#F0F4F8";
    public static final String TEXT_DARK  = "#2C3E50";
    public static final String TEXT_MUTED = "#7F8C8D";

    // ── BUTTONS ────────────────────────────────────────────────────────────────

    public static Button primaryButton(String text) {
        Button btn = new Button(text);
        applyButtonStyle(btn, GREEN, GREEN_DARK);
        return btn;
    }

    public static Button secondaryButton(String text) {
        Button btn = new Button(text);
        applyButtonStyle(btn, BLUE, BLUE_DARK);
        return btn;
    }

    public static Button dangerButton(String text) {
        Button btn = new Button(text);
        applyButtonStyle(btn, RED, RED_DARK);
        return btn;
    }

    public static Button warningButton(String text) {
        Button btn = new Button(text);
        applyButtonStyle(btn, ORANGE, "#D68910");
        return btn;
    }

    public static Button outlineButton(String text) {
        Button btn = new Button(text);
        btn.setStyle(
            "-fx-background-color: transparent;" +
            "-fx-border-color: " + GREEN + ";" +
            "-fx-border-radius: 8;" +
            "-fx-background-radius: 8;" +
            "-fx-text-fill: " + GREEN + ";" +
            "-fx-font-weight: bold;" +
            "-fx-padding: 9 19 9 19;" +
            "-fx-cursor: hand;" +
            "-fx-font-size: 13px;" +
            "-fx-border-width: 2;"
        );
        btn.setOnMouseEntered(e -> btn.setStyle(
            "-fx-background-color: " + GREEN + ";" +
            "-fx-border-color: " + GREEN + ";" +
            "-fx-border-radius: 8;" +
            "-fx-background-radius: 8;" +
            "-fx-text-fill: white;" +
            "-fx-font-weight: bold;" +
            "-fx-padding: 9 19 9 19;" +
            "-fx-cursor: hand;" +
            "-fx-font-size: 13px;" +
            "-fx-border-width: 2;"
        ));
        btn.setOnMouseExited(e -> btn.setStyle(
            "-fx-background-color: transparent;" +
            "-fx-border-color: " + GREEN + ";" +
            "-fx-border-radius: 8;" +
            "-fx-background-radius: 8;" +
            "-fx-text-fill: " + GREEN + ";" +
            "-fx-font-weight: bold;" +
            "-fx-padding: 9 19 9 19;" +
            "-fx-cursor: hand;" +
            "-fx-font-size: 13px;" +
            "-fx-border-width: 2;"
        ));
        return btn;
    }

    private static void applyButtonStyle(Button btn, String base, String hover) {
        String baseStyle = "-fx-background-color: " + base + ";" +
                "-fx-text-fill: white;" +
                "-fx-font-weight: bold;" +
                "-fx-background-radius: 8;" +
                "-fx-padding: 10 20 10 20;" +
                "-fx-cursor: hand;" +
                "-fx-font-size: 13px;";
        String hoverStyle = "-fx-background-color: " + hover + ";" +
                "-fx-text-fill: white;" +
                "-fx-font-weight: bold;" +
                "-fx-background-radius: 8;" +
                "-fx-padding: 10 20 10 20;" +
                "-fx-cursor: hand;" +
                "-fx-font-size: 13px;";
        btn.setStyle(baseStyle);
        btn.setOnMouseEntered(e -> btn.setStyle(hoverStyle));
        btn.setOnMouseExited(e -> btn.setStyle(baseStyle));
        addHoverScale(btn);
    }

    // ── TEXT FIELDS ────────────────────────────────────────────────────────────

    public static TextField styledTextField(String prompt) {
        TextField f = new TextField();
        f.setPromptText(prompt);
        applyFieldStyle(f);
        return f;
    }

    public static PasswordField styledPasswordField(String prompt) {
        PasswordField f = new PasswordField();
        f.setPromptText(prompt);
        applyFieldStyle(f);
        return f;
    }

    public static TextArea styledTextArea(String prompt, int rows) {
        TextArea ta = new TextArea();
        ta.setPromptText(prompt);
        ta.setPrefRowCount(rows);
        ta.setWrapText(true);
        ta.setStyle(
            "-fx-background-radius: 8;" +
            "-fx-border-radius: 8;" +
            "-fx-border-color: #D5D8DC;" +
            "-fx-border-width: 1.5;" +
            "-fx-padding: 8 12 8 12;" +
            "-fx-font-size: 13px;"
        );
        return ta;
    }

    private static void applyFieldStyle(TextField f) {
        String base = "-fx-background-radius: 8;" +
                "-fx-border-radius: 8;" +
                "-fx-border-color: #D5D8DC;" +
                "-fx-border-width: 1.5;" +
                "-fx-padding: 9 13 9 13;" +
                "-fx-font-size: 13px;" +
                "-fx-background-color: white;";
        String focused = "-fx-background-radius: 8;" +
                "-fx-border-radius: 8;" +
                "-fx-border-color: " + GREEN + ";" +
                "-fx-border-width: 2;" +
                "-fx-padding: 9 13 9 13;" +
                "-fx-font-size: 13px;" +
                "-fx-background-color: white;";
        f.setStyle(base);
        f.focusedProperty().addListener((obs, o, n) -> f.setStyle(n ? focused : base));
    }

    // ── LABELS ────────────────────────────────────────────────────────────────

    public static Label pageTitle(String text) {
        Label l = new Label(text);
        l.setFont(Font.font("Segoe UI", FontWeight.BOLD, 24));
        l.setStyle("-fx-text-fill: " + TEXT_DARK + ";");
        return l;
    }

    public static Label sectionTitle(String text) {
        Label l = new Label(text);
        l.setFont(Font.font("Segoe UI", FontWeight.BOLD, 18));
        l.setStyle("-fx-text-fill: " + TEXT_DARK + ";");
        return l;
    }

    public static Label formLabel(String text) {
        Label l = new Label(text);
        l.setFont(Font.font("Segoe UI", FontWeight.SEMI_BOLD, 13));
        l.setStyle("-fx-text-fill: " + TEXT_MUTED + ";");
        return l;
    }

    public static Label badge(String text, String bg, String fg) {
        Label l = new Label(text);
        l.setStyle(
            "-fx-background-color: " + bg + ";" +
            "-fx-text-fill: " + fg + ";" +
            "-fx-background-radius: 12;" +
            "-fx-padding: 4 10 4 10;" +
            "-fx-font-size: 11px;" +
            "-fx-font-weight: bold;"
        );
        return l;
    }

    public static Label successBadge(String text) { return badge(text, "#D5E8D4", "#1E8449"); }
    public static Label warningBadge(String text) { return badge(text, "#FEF9E7", "#D4AC0D"); }
    public static Label dangerBadge(String text) { return badge(text, "#FADBD8", "#C0392B"); }
    public static Label infoBadge(String text) { return badge(text, "#D6EAF8", "#2471A3"); }

    // ── CARDS ────────────────────────────────────────────────────────────────

    public static VBox card(double padding) {
        VBox v = new VBox(10);
        v.setPadding(new Insets(padding));
        v.setStyle(
            "-fx-background-color: white;" +
            "-fx-background-radius: 12;" +
            "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.10), 14, 0, 0, 4);"
        );
        return v;
    }

    public static VBox statCard(String value, String label, String bgColor) {
        Label valLbl = new Label(value);
        valLbl.setFont(Font.font("Segoe UI", FontWeight.BOLD, 28));
        valLbl.setStyle("-fx-text-fill: white;");

        Label nameLbl = new Label(label);
        nameLbl.setStyle("-fx-text-fill: rgba(255,255,255,0.85); -fx-font-size: 13px;");

        VBox box = new VBox(4, valLbl, nameLbl);
        box.setPadding(new Insets(18, 22, 18, 22));
        box.setAlignment(Pos.CENTER_LEFT);
        box.setStyle(
            "-fx-background-color: " + bgColor + ";" +
            "-fx-background-radius: 12;" +
            "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.14), 12, 0, 0, 3);" +
            "-fx-cursor: hand;"
        );
        addHoverScale(box);
        return box;
    }

    // ── DIVIDER ───────────────────────────────────────────────────────────────

    public static Region divider() {
        Region r = new Region();
        r.setPrefHeight(1);
        r.setStyle("-fx-background-color: #E8EAED;");
        return r;
    }

    // ── ANIMATIONS ─────────────────────────────────────────────────────────────

    public static void fadeIn(javafx.scene.Node node, double seconds) {
        FadeTransition ft = new FadeTransition(Duration.seconds(seconds), node);
        ft.setFromValue(0);
        ft.setToValue(1);
        ft.play();
    }

    private static void addHoverScale(javafx.scene.Node node) {
        node.setOnMouseEntered(e -> {
            ScaleTransition st = new ScaleTransition(Duration.millis(150), node);
            st.setToX(1.03); st.setToY(1.03);
            st.play();
        });
        node.setOnMouseExited(e -> {
            ScaleTransition st = new ScaleTransition(Duration.millis(150), node);
            st.setToX(1.0); st.setToY(1.0);
            st.play();
        });
    }

    // ── ALERTS ────────────────────────────────────────────────────────────────

    public static void showInfo(String title, String msg) {
        Alert a = new Alert(Alert.AlertType.INFORMATION);
        a.setTitle(title); a.setHeaderText(null); a.setContentText(msg);
        styleAlert(a); a.showAndWait();
    }

    public static void showError(String title, String msg) {
        Alert a = new Alert(Alert.AlertType.ERROR);
        a.setTitle(title); a.setHeaderText(null); a.setContentText(msg);
        styleAlert(a); a.showAndWait();
    }

    public static void showWarning(String title, String msg) {
        Alert a = new Alert(Alert.AlertType.WARNING);
        a.setTitle(title); a.setHeaderText(null); a.setContentText(msg);
        styleAlert(a); a.showAndWait();
    }

    public static boolean showConfirm(String title, String msg) {
        Alert a = new Alert(Alert.AlertType.CONFIRMATION);
        a.setTitle(title); a.setHeaderText(null); a.setContentText(msg);
        styleAlert(a);
        return a.showAndWait().filter(r -> r == ButtonType.OK).isPresent();
    }

    private static void styleAlert(Alert a) {
        a.getDialogPane().setStyle("-fx-font-family: 'Segoe UI'; -fx-font-size: 13px;");
    }

    // ── COMBOBOX ─────────────────────────────────────────────────────────────

    public static <T> ComboBox<T> styledComboBox(String prompt) {
        ComboBox<T> cb = new ComboBox<>();
        cb.setPromptText(prompt);
        cb.setStyle(
            "-fx-background-radius: 8;" +
            "-fx-border-radius: 8;" +
            "-fx-border-color: #D5D8DC;" +
            "-fx-background-color: white;" +
            "-fx-font-size: 13px;" +
            "-fx-padding: 4 8 4 8;"
        );
        cb.setPrefHeight(38);
        return cb;
    }
}
