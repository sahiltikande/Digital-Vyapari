package com.digitalvyapari.view;

/** Legacy data holder - kept for compatibility. Use Session/Controller instead. */
public class FarmerData {
    private static String name = "", email = "", address = "";
    private static String materialType = "", material = "", quantity = "", rate = "";

    public static void setData(String n, String e, String a, String mt, String m, String q, String r) {
        name = n; email = e; address = a; materialType = mt; material = m; quantity = q; rate = r;
    }
    public static String getName()         { return name; }
    public static String getEmail()        { return email; }
    public static String getAddress()      { return address; }
    public static String getMaterialType() { return materialType; }
    public static String getMaterial()     { return material; }
    public static String getQuantity()     { return quantity; }
    public static String getRate()         { return rate; }
}
