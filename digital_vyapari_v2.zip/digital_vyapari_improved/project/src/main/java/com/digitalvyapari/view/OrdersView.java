package com.digitalvyapari.view;

import com.google.firebase.database.*;
import javafx.animation.FadeTransition;
import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.util.Duration;

/** Legacy real-time orders loader - still used in ShopKeeper legacy view */
public class OrdersView {

    public static void loadOrders(VBox ordersBox) {
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("orders");
        ordersBox.getChildren().clear();

        ref.addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(DataSnapshot snapshot, String prev) {
                Platform.runLater(() -> {
                    Node card = createOrderCard(snapshot);
                    card.setOpacity(0);
                    FadeTransition ft = new FadeTransition(Duration.millis(500), card);
                    ft.setToValue(1); ft.play();
                    ordersBox.getChildren().add(0, card);
                });
            }
            @Override public void onChildChanged(DataSnapshot s, String p) {}
            @Override public void onChildRemoved(DataSnapshot s) {
                Platform.runLater(() -> loadOrders(ordersBox));
            }
            @Override public void onChildMoved(DataSnapshot s, String p) {}
            @Override public void onCancelled(DatabaseError e) {
                Platform.runLater(() -> ordersBox.getChildren().add(
                    new Label("Error: " + e.getMessage())));
            }
        });
    }

    private static Node createOrderCard(DataSnapshot s) {
        String name = s.child("name").getValue(String.class);
        String material = s.child("material").getValue(String.class);
        Long qty = s.child("quantity").getValue(Long.class);
        Long rate = s.child("rate").getValue(Long.class);
        if (name == null || material == null || qty == null || rate == null)
            return new Label("");

        String text = String.format("🧾 %s | 📦 %s | %d kg @ ₹%d = ₹%d", name, material, qty, rate, qty * rate);
        Label lbl = new Label(text);
        lbl.setPadding(new Insets(12));
        lbl.setStyle(
            "-fx-background-color: #e8f5e9; -fx-background-radius: 8;" +
            "-fx-border-color: #a5d6a7; -fx-border-radius: 8; -fx-font-size: 14px;");
        return lbl;
    }
}
