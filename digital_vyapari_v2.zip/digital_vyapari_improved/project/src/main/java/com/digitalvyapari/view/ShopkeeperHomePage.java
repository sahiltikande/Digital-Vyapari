package com.digitalvyapari.view;

import com.digitalvyapari.Controller.MaterialController;
import com.digitalvyapari.Controller.MaterialController.MaterialEntry;
import com.digitalvyapari.Controller.ShopkeeperController;
import com.digitalvyapari.Utils.Session;
import com.digitalvyapari.Utils.UIHelper;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

import java.util.*;
import java.util.stream.Collectors;

public class ShopkeeperHomePage extends Application {

    private VBox postContainer;
    private StackPane rootStack;
    private StackPane overlayContainer = null;
    private List<MaterialEntry> allEntries = new ArrayList<>();
    private TextField searchField;
    private ComboBox<String> typeFilter;
    private Label countLabel;

    @Override
    public void start(Stage stage) {
        stage.setTitle("Digital Vyapari - Shopkeeper");

        rootStack = new StackPane();

        BorderPane mainLayout = new BorderPane();
        mainLayout.setStyle("-fx-background-color: #F0F4F8;");
        mainLayout.setTop(buildTopBar(stage));
        mainLayout.setCenter(buildContent(stage));

        // Sidebar for shopkeeper
        Sidebar sidebar = new Sidebar(stage, "Dashboard");

        HBox withSidebar = new HBox(sidebar, mainLayout);
        HBox.setHgrow(mainLayout, Priority.ALWAYS);

        rootStack.getChildren().add(withSidebar);

        Scene scene = new Scene(rootStack, 1400, 850);
        scene.setOnKeyPressed(e -> {
            if (e.getCode() == javafx.scene.input.KeyCode.ESCAPE) removeOverlay();
        });

        stage.setScene(scene);
        stage.setFullScreen(true);
        stage.show();

        loadPosts();
    }

    private HBox buildTopBar(Stage stage) {
        Label title = new Label("🏪 Available Materials");
        title.setFont(Font.font("Segoe UI", FontWeight.BOLD, 22));
        title.setStyle("-fx-text-fill: #2C3E50;");
        Label sub = new Label("Browse and buy materials from farmers");
        sub.setStyle("-fx-text-fill: #7F8C8D; -fx-font-size: 13px;");
        VBox titleBox = new VBox(2, title, sub);

        Region spacer = new Region(); HBox.setHgrow(spacer, Priority.ALWAYS);

        Button refreshBtn = UIHelper.outlineButton("↻  Refresh");
        refreshBtn.setOnAction(e -> loadPosts());

        Button ordersBtn = UIHelper.secondaryButton("📋  My Orders");
        ordersBtn.setOnAction(e -> new OrdersPage().start(stage));

        HBox bar = new HBox(16, titleBox, spacer, refreshBtn, ordersBtn);
        bar.setAlignment(Pos.CENTER_LEFT);
        bar.setPadding(new Insets(16, 24, 16, 24));
        bar.setStyle(
            "-fx-background-color: white;" +
            "-fx-border-color: #E8EAED;" +
            "-fx-border-width: 0 0 1 0;" +
            "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.06), 6, 0, 0, 2);"
        );
        return bar;
    }

    private BorderPane buildContent(Stage stage) {
        // ── Filter bar ────────────────────────────────────────────────────────
        searchField = new TextField();
        searchField.setPromptText("🔍  Search materials...");
        searchField.setPrefWidth(280);
        searchField.setStyle(
            "-fx-background-radius: 20; -fx-border-radius: 20;" +
            "-fx-border-color: #D5D8DC; -fx-padding: 8 16 8 16;" +
            "-fx-font-size: 13px;"
        );
        searchField.textProperty().addListener((o, old, n) -> applyFilters());

        typeFilter = UIHelper.styledComboBox("All Categories");
        typeFilter.getItems().addAll("All", "Vegetables", "Fruits", "Sprouts", "Grains", "Dairy", "Spices", "Other");
        typeFilter.setValue("All");
        typeFilter.setPrefWidth(160);
        typeFilter.setOnAction(e -> applyFilters());

        countLabel = new Label("Loading...");
        countLabel.setStyle("-fx-text-fill: #7F8C8D; -fx-font-size: 13px;");

        HBox filterBar = new HBox(12, searchField, typeFilter, countLabel);
        filterBar.setAlignment(Pos.CENTER_LEFT);
        filterBar.setPadding(new Insets(14, 20, 14, 20));
        filterBar.setStyle("-fx-background-color: white; -fx-border-color: #E8EAED; -fx-border-width: 0 0 1 0;");

        // ── Post container ────────────────────────────────────────────────────
        postContainer = new VBox(16);
        postContainer.setPadding(new Insets(20));

        ScrollPane scroll = new ScrollPane(postContainer);
        scroll.setFitToWidth(true);
        scroll.setStyle("-fx-background-color: #F0F4F8; -fx-border-color: transparent;");

        BorderPane content = new BorderPane();
        content.setTop(filterBar);
        content.setCenter(scroll);
        return content;
    }

    private void loadPosts() {
        Platform.runLater(() -> {
            postContainer.getChildren().clear();
            ProgressIndicator pi = new ProgressIndicator();
            pi.setMaxSize(40, 40);
            VBox loading = new VBox(pi, new Label("Loading materials..."));
            loading.setAlignment(Pos.CENTER); loading.setSpacing(8);
            postContainer.getChildren().add(loading);
        });

        new Thread(() -> {
            List<MaterialEntry> materials = MaterialController.getMaterialData();
            // Merge same material+type+rate
            Map<String, MaterialEntry> merged = new LinkedHashMap<>();
            for (MaterialEntry e : materials) {
                String key = (e.getType() + "-" + e.getMaterial() + "-" + (int) e.getRate()).toLowerCase();
                if (merged.containsKey(key)) {
                    MaterialEntry existing = merged.get(key);
                    existing.setQuantity(existing.getQuantity() + e.getQuantity());
                } else {
                    merged.put(key, e);
                }
            }
            allEntries = merged.values().stream()
                .filter(e -> e.getQuantity() > 0)
                .sorted(Comparator.comparing(MaterialEntry::getType))
                .collect(Collectors.toList());

            Platform.runLater(() -> {
                applyFilters();
            });
        }).start();
    }

    private void applyFilters() {
        String search = searchField != null ? searchField.getText().toLowerCase().trim() : "";
        String type   = typeFilter != null ? typeFilter.getValue() : "All";
        if (type == null || type.equals("All")) type = "";
        final String ft = type;

        List<MaterialEntry> filtered = allEntries.stream()
            .filter(e -> search.isEmpty()
                || e.getMaterial().toLowerCase().contains(search)
                || e.getType().toLowerCase().contains(search))
            .filter(e -> ft.isEmpty() || e.getType().equals(ft))
            .collect(Collectors.toList());

        postContainer.getChildren().clear();
        countLabel.setText(filtered.size() + " items available");

        if (filtered.isEmpty()) {
            Label empty = new Label("No materials match your search.");
            empty.setStyle("-fx-text-fill: #7F8C8D; -fx-font-size: 15px;");
            postContainer.getChildren().add(empty);
            return;
        }

        // Group by type
        Map<String, List<MaterialEntry>> grouped = filtered.stream()
            .collect(Collectors.groupingBy(MaterialEntry::getType, LinkedHashMap::new, Collectors.toList()));

        for (Map.Entry<String, List<MaterialEntry>> group : grouped.entrySet()) {
            Label catTitle = new Label("📦 " + group.getKey());
            catTitle.setFont(Font.font("Segoe UI", FontWeight.BOLD, 15));
            catTitle.setStyle("-fx-text-fill: #2C3E50;");
            postContainer.getChildren().add(catTitle);

            FlowPane flowPane = new FlowPane(16, 16);
            flowPane.setPrefWrapLength(900);
            for (MaterialEntry e : group.getValue()) {
                flowPane.getChildren().add(createPostCard(e));
            }
            postContainer.getChildren().add(flowPane);
        }
    }

    private VBox createPostCard(MaterialEntry entry) {
        Label typeLabel = UIHelper.infoBadge(entry.getType());

        Label materialLabel = new Label(capitalize(entry.getMaterial()));
        materialLabel.setFont(Font.font("Segoe UI", FontWeight.BOLD, 16));
        materialLabel.setStyle("-fx-text-fill: #2C3E50;");

        Label qtyLabel = new Label("Available: " + String.format("%.1f", entry.getQuantity()) + " kg");
        qtyLabel.setStyle("-fx-text-fill: #5D6D7E; -fx-font-size: 13px;");

        Label rateLabel = new Label("₹" + String.format("%.2f", entry.getRate()) + " / kg");
        rateLabel.setFont(Font.font("Segoe UI", FontWeight.BOLD, 18));
        rateLabel.setStyle("-fx-text-fill: #27AE60;");

        // Stock status
        Label stockBadge = entry.isLowStock()
            ? UIHelper.dangerBadge("Low Stock")
            : UIHelper.successBadge("In Stock");

        Region spacer = new Region(); HBox.setHgrow(spacer, Priority.ALWAYS);
        HBox statusRow = new HBox(8, rateLabel, spacer, stockBadge);
        statusRow.setAlignment(Pos.CENTER_LEFT);

        Button buyBtn = UIHelper.primaryButton("🛒  Buy Now");
        buyBtn.setPrefWidth(Double.MAX_VALUE);
        buyBtn.setOnAction(e -> showBuyModal(entry));

        VBox card = new VBox(10, typeLabel, materialLabel, qtyLabel, statusRow, new Separator(), buyBtn);
        card.setPadding(new Insets(18));
        card.setPrefWidth(240);
        card.setStyle(
            "-fx-background-color: white;" +
            "-fx-background-radius: 12;" +
            "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.10), 12, 0, 0, 3);" +
            "-fx-cursor: hand;"
        );
        card.setOnMouseEntered(e -> card.setStyle(
            "-fx-background-color: white;" +
            "-fx-background-radius: 12;" +
            "-fx-effect: dropshadow(gaussian, rgba(39,174,96,0.25), 16, 0, 0, 5);" +
            "-fx-cursor: hand;" +
            "-fx-border-color: #27AE60;" +
            "-fx-border-width: 1.5;" +
            "-fx-border-radius: 12;"
        ));
        card.setOnMouseExited(e -> card.setStyle(
            "-fx-background-color: white;" +
            "-fx-background-radius: 12;" +
            "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.10), 12, 0, 0, 3);" +
            "-fx-cursor: hand;"
        ));
        return card;
    }

    private void showBuyModal(MaterialEntry entry) {
        // ── Input fields ──────────────────────────────────────────────────────
        TextField nameField = UIHelper.styledTextField("Your name");
        TextField addrField = UIHelper.styledTextField("Delivery address");
        TextField qtyField  = UIHelper.styledTextField("Quantity (max " + (int) entry.getQuantity() + " kg)");

        Label totalLabel = new Label("Total: ₹0.00");
        totalLabel.setFont(Font.font("Segoe UI", FontWeight.BOLD, 18));
        totalLabel.setStyle("-fx-text-fill: #27AE60;");

        qtyField.textProperty().addListener((o, old, n) -> {
            try {
                int qty = Integer.parseInt(n.trim());
                if (qty > 0 && qty <= entry.getQuantity()) {
                    totalLabel.setText("Total: ₹" + String.format("%.2f", qty * entry.getRate()));
                    totalLabel.setStyle("-fx-text-fill: #27AE60; -fx-font-size: 18px; -fx-font-weight: bold;");
                } else {
                    totalLabel.setText("Invalid quantity");
                    totalLabel.setStyle("-fx-text-fill: #E74C3C; -fx-font-size: 13px;");
                }
            } catch (Exception e) {
                totalLabel.setText("Total: ₹0.00");
            }
        });

        Label errorLbl = new Label();
        errorLbl.setStyle("-fx-text-fill: #E74C3C; -fx-font-size: 12px;");

        // Pre-fill customer name from session
        nameField.setText(Session.getCurrentUserName().equals("User") ? "" : Session.getCurrentUserName());

        Button placeBtn = UIHelper.primaryButton("✅  Place Order");
        placeBtn.setPrefWidth(180);
        Button cancelBtn = UIHelper.dangerButton("✕  Cancel");
        cancelBtn.setPrefWidth(120);
        cancelBtn.setOnAction(e -> removeOverlay());

        placeBtn.setOnAction(e -> {
            errorLbl.setText("");
            String name = nameField.getText().trim();
            String addr = addrField.getText().trim();
            String qStr = qtyField.getText().trim();

            if (name.isEmpty() || addr.isEmpty() || qStr.isEmpty()) {
                errorLbl.setText("All fields are required."); return;
            }
            try {
                int qty = Integer.parseInt(qStr);
                if (qty <= 0 || qty > entry.getQuantity()) {
                    errorLbl.setText("Quantity must be between 1 and " + (int) entry.getQuantity());
                    return;
                }
                ShopkeeperController.placeOrder(name, addr, entry, qty);
                ShopkeeperController.updateInventoryQuantity(entry, qty);
                removeOverlay();
                UIHelper.showInfo("Order Placed!", "Your order for " + qty + " kg of "
                    + capitalize(entry.getMaterial()) + " has been placed. Total: ₹"
                    + String.format("%.2f", qty * entry.getRate()));
                loadPosts(); // Refresh
            } catch (NumberFormatException ex) {
                errorLbl.setText("Enter a valid number.");
            }
        });

        HBox btnRow = new HBox(12, placeBtn, cancelBtn);
        btnRow.setAlignment(Pos.CENTER_RIGHT);

        // ── Modal content ─────────────────────────────────────────────────────
        Label modalTitle = new Label("🛒 Place Order");
        modalTitle.setFont(Font.font("Segoe UI", FontWeight.BOLD, 18));
        Label modalSub = new Label(capitalize(entry.getMaterial()) + " @ ₹" + entry.getRate() + "/kg");
        modalSub.setStyle("-fx-text-fill: #7F8C8D;");

        VBox form = new VBox(14,
            modalTitle, modalSub, new Separator(),
            labeledField("Customer Name", nameField),
            labeledField("Delivery Address", addrField),
            labeledField("Quantity (kg)", qtyField),
            totalLabel, errorLbl, btnRow
        );
        form.setPadding(new Insets(28));
        form.setMaxWidth(420);
        form.setStyle(
            "-fx-background-color: white;" +
            "-fx-background-radius: 14;" +
            "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.35), 30, 0, 0, 8);"
        );

        Region bg = new Region();
        bg.setStyle("-fx-background-color: rgba(0,0,0,0.45);");

        overlayContainer = new StackPane(bg, form);
        StackPane.setAlignment(form, Pos.CENTER);
        rootStack.getChildren().add(overlayContainer);
    }

    private VBox labeledField(String label, TextField field) {
        Label lbl = new Label(label);
        lbl.setStyle("-fx-text-fill: #5D6D7E; -fx-font-size: 12px; -fx-font-weight: bold;");
        field.setPrefWidth(360);
        return new VBox(5, lbl, field);
    }

    private void removeOverlay() {
        if (overlayContainer != null) {
            rootStack.getChildren().remove(overlayContainer);
            overlayContainer = null;
        }
    }

    private String capitalize(String s) {
        if (s == null || s.isEmpty()) return s;
        return Character.toUpperCase(s.charAt(0)) + s.substring(1);
    }
}
