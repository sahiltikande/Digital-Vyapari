package com.digitalvyapari.view;

import javafx.application.Application;
import javafx.stage.Stage;

/** Legacy class - functionality moved to ShopkeeperHomePage */
public class ShopKeeper extends Application {
    @Override
    public void start(Stage stage) {
        new ShopkeeperHomePage().start(stage);
    }
}
