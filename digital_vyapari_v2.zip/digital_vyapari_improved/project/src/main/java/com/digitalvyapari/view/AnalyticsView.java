package com.digitalvyapari.view;

import com.digitalvyapari.Controller.MaterialController;
import com.digitalvyapari.Controller.MaterialController.MaterialEntry;
import com.digitalvyapari.Utils.UIHelper;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.chart.*;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

import java.util.*;

public class AnalyticsView extends Application {

    @Override
    public void start(Stage stage) {
        stage.setTitle("Digital Vyapari - Analytics");

        Sidebar sidebar = new Sidebar(stage, "Analytics");

        BorderPane mainArea = new BorderPane();
        mainArea.setStyle("-fx-background-color: #F0F4F8;");
        mainArea.setTop(buildTopBar());

        // Loading placeholder
        ProgressIndicator loading = new ProgressIndicator();
        loading.setMaxSize(60, 60);
        VBox loadBox = new VBox(loading, new Label("Loading analytics..."));
        loadBox.setAlignment(Pos.CENTER); loadBox.setSpacing(10);
        mainArea.setCenter(loadBox);

        HBox root = new HBox(sidebar, mainArea);
        HBox.setHgrow(mainArea, Priority.ALWAYS);

        Scene scene = new Scene(root, 1400, 850);
        stage.setScene(scene);
        stage.setFullScreen(true);
        stage.show();

        // Load data
        new Thread(() -> {
            List<MaterialEntry> entries = MaterialController.getMaterialData();
            Platform.runLater(() -> mainArea.setCenter(buildContent(entries)));
        }).start();
    }

    private HBox buildTopBar() {
        Label title = new Label("📊 Analytics & Insights");
        title.setFont(Font.font("Segoe UI", FontWeight.BOLD, 22));
        title.setStyle("-fx-text-fill: #2C3E50;");
        Label sub = new Label("AI-powered analysis of your inventory data");
        sub.setStyle("-fx-text-fill: #7F8C8D; -fx-font-size: 13px;");
        VBox titleBox = new VBox(2, title, sub);
        HBox bar = new HBox(titleBox);
        bar.setPadding(new Insets(16, 24, 16, 24));
        bar.setStyle(
            "-fx-background-color: white;" +
            "-fx-border-color: #E8EAED;" +
            "-fx-border-width: 0 0 1 0;" +
            "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.06), 6, 0, 0, 2);"
        );
        return bar;
    }

    private ScrollPane buildContent(List<MaterialEntry> entries) {
        // ── Summary stats row ─────────────────────────────────────────────────
        Map<String, Object> stats = MaterialController.getDashboardStats(entries);
        double totalVal = (double) stats.get("totalValue");
        double totalQty = (double) stats.get("totalQuantity");
        long typesCount = (long) stats.get("typesCount");

        VBox s1 = UIHelper.statCard("₹" + String.format("%,.0f", totalVal), "Total Inventory Value", "#27AE60");
        VBox s2 = UIHelper.statCard(String.format("%,.0f kg", totalQty), "Total Stock", "#3498DB");
        VBox s3 = UIHelper.statCard(String.valueOf(entries.size()), "Total Records", "#9B59B6");
        VBox s4 = UIHelper.statCard(String.valueOf(typesCount), "Categories", "#E67E22");
        for (VBox v : new VBox[]{s1, s2, s3, s4}) HBox.setHgrow(v, Priority.ALWAYS);
        HBox statsRow = new HBox(16, s1, s2, s3, s4);

        // ── Charts ────────────────────────────────────────────────────────────
        VBox barCard   = wrapChart(buildQuantityBar(entries), "📦 Quantity by Category");
        VBox pieCard   = wrapChart(buildValuePie(entries),    "💰 Value Distribution");
        VBox lineCard  = wrapChart(buildTopMaterialBar(entries), "🏆 Top 8 Materials by Quantity");

        HBox row1 = new HBox(16, barCard, pieCard);
        HBox.setHgrow(barCard, Priority.ALWAYS);
        HBox.setHgrow(pieCard, Priority.ALWAYS);

        HBox row2 = new HBox(lineCard);
        HBox.setHgrow(lineCard, Priority.ALWAYS);

        // ── AI Insights ────────────────────────────────────────────────────────
        VBox insightsCard = buildAIInsights(entries);
        VBox topSellersCard = buildTopSellersCard(entries);
        VBox slowMoversCard = buildSlowMoversCard(entries);

        HBox row3 = new HBox(16, insightsCard, topSellersCard, slowMoversCard);
        HBox.setHgrow(insightsCard, Priority.ALWAYS);
        HBox.setHgrow(topSellersCard, Priority.ALWAYS);
        HBox.setHgrow(slowMoversCard, Priority.ALWAYS);

        VBox content = new VBox(20, statsRow, row1, row2, row3);
        content.setPadding(new Insets(24));

        ScrollPane scroll = new ScrollPane(content);
        scroll.setFitToWidth(true);
        scroll.setStyle("-fx-background-color: #F0F4F8; -fx-border-color: transparent;");
        return scroll;
    }

    // ── Chart Builders ────────────────────────────────────────────────────────

    private BarChart<String, Number> buildQuantityBar(List<MaterialEntry> entries) {
        Map<String, Double> byType = MaterialController.getQuantityByType(entries);
        CategoryAxis x = new CategoryAxis();
        NumberAxis y = new NumberAxis();
        x.setLabel("Category"); y.setLabel("Quantity (kg)");

        BarChart<String, Number> chart = new BarChart<>(x, y);
        XYChart.Series<String, Number> series = new XYChart.Series<>();
        series.setName("Quantity");
        byType.forEach((k, v) -> series.getData().add(new XYChart.Data<>(k, v)));
        chart.getData().add(series);
        chart.setLegendVisible(false);
        chart.setAnimated(false);
        chart.setPrefHeight(260);
        return chart;
    }

    private PieChart buildValuePie(List<MaterialEntry> entries) {
        Map<String, Double> byValue = MaterialController.getValueByType(entries);
        ObservableList<PieChart.Data> data = FXCollections.observableArrayList();
        byValue.forEach((k, v) -> data.add(new PieChart.Data(k + "\n₹" + String.format("%,.0f", v), v)));
        PieChart chart = new PieChart(data);
        chart.setLabelsVisible(true);
        chart.setAnimated(false);
        chart.setPrefHeight(260);
        return chart;
    }

    private BarChart<String, Number> buildTopMaterialBar(List<MaterialEntry> entries) {
        List<MaterialEntry> top = MaterialController.getTopSellers(entries);
        if (top.size() > 8) top = top.subList(0, 8);

        CategoryAxis x = new CategoryAxis();
        NumberAxis y = new NumberAxis();
        x.setLabel("Material"); y.setLabel("Quantity (kg)");

        BarChart<String, Number> chart = new BarChart<>(x, y);
        XYChart.Series<String, Number> series = new XYChart.Series<>();
        series.setName("Qty");
        for (MaterialEntry e : top) {
            series.getData().add(new XYChart.Data<>(capitalize(e.getMaterial()), e.getQuantity()));
        }
        chart.getData().add(series);
        chart.setLegendVisible(false);
        chart.setAnimated(false);
        chart.setPrefHeight(240);
        return chart;
    }

    private VBox wrapChart(javafx.scene.chart.Chart chart, String title) {
        Label lbl = new Label(title);
        lbl.setFont(Font.font("Segoe UI", FontWeight.BOLD, 14));
        lbl.setStyle("-fx-text-fill: #2C3E50;");
        chart.setStyle("-fx-background-color: transparent;");
        VBox card = new VBox(10, lbl, new Separator(), chart);
        card.setPadding(new Insets(18, 16, 16, 16));
        card.setStyle(
            "-fx-background-color: white;" +
            "-fx-background-radius: 12;" +
            "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.09), 12, 0, 0, 4);"
        );
        VBox.setVgrow(chart, Priority.ALWAYS);
        return card;
    }

    // ── AI Cards ──────────────────────────────────────────────────────────────

    private VBox buildAIInsights(List<MaterialEntry> entries) {
        Label title = new Label("🤖 Smart Insights");
        title.setFont(Font.font("Segoe UI", FontWeight.BOLD, 15));
        title.setStyle("-fx-text-fill: #2C3E50;");

        VBox insightsList = new VBox(10);
        List<MaterialEntry> top  = MaterialController.getTopSellers(entries);
        List<MaterialEntry> slow = MaterialController.getSlowMovers(entries);
        Map<String, Double> byType = MaterialController.getQuantityByType(entries);

        if (!top.isEmpty()) {
            addInsight(insightsList, "🏆",
                "Best performer: " + capitalize(top.get(0).getMaterial()),
                top.get(0).getQuantity() + " kg available", "#27AE60");
        }
        if (!slow.isEmpty()) {
            addInsight(insightsList, "🐢",
                "Needs attention: " + capitalize(slow.get(0).getMaterial()),
                "Only " + slow.get(0).getQuantity() + " kg in stock", "#E67E22");
        }
        // Most common category
        byType.entrySet().stream()
            .max(Map.Entry.comparingByValue())
            .ifPresent(e -> addInsight(insightsList, "📦",
                "Dominant category: " + e.getKey(),
                String.format("%.0f kg total", e.getValue()), "#3498DB"));

        // Low stock count
        long lowCount = entries.stream().filter(MaterialEntry::isLowStock).count();
        if (lowCount > 0) {
            addInsight(insightsList, "⚠️",
                lowCount + " items need restocking",
                "Stock below 10 kg threshold", "#E74C3C");
        } else {
            addInsight(insightsList, "✅", "All items are well-stocked", "No alerts", "#27AE60");
        }

        VBox card = new VBox(12, title, new Separator(), insightsList);
        card.setPadding(new Insets(18, 20, 18, 20));
        card.setStyle(
            "-fx-background-color: white;" +
            "-fx-background-radius: 12;" +
            "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.09), 12, 0, 0, 4);"
        );
        return card;
    }

    private void addInsight(VBox box, String icon, String heading, String detail, String color) {
        Label iconLbl = new Label(icon);
        iconLbl.setFont(Font.font(20));
        Label headLbl = new Label(heading);
        headLbl.setFont(Font.font("Segoe UI", FontWeight.BOLD, 13));
        headLbl.setStyle("-fx-text-fill: " + color + ";");
        Label detLbl = new Label(detail);
        detLbl.setStyle("-fx-text-fill: #7F8C8D; -fx-font-size: 11px;");
        VBox text = new VBox(2, headLbl, detLbl);
        HBox row = new HBox(10, iconLbl, text);
        row.setPadding(new Insets(8, 12, 8, 12));
        row.setStyle(
            "-fx-background-color: derive(" + color + ", 92%);" +
            "-fx-background-radius: 8;"
        );
        box.getChildren().add(row);
    }

    private VBox buildTopSellersCard(List<MaterialEntry> entries) {
        Label title = new Label("🏆 Top Sellers");
        title.setFont(Font.font("Segoe UI", FontWeight.BOLD, 15));
        title.setStyle("-fx-text-fill: #2C3E50;");

        VBox list = new VBox(8);
        List<MaterialEntry> top = MaterialController.getTopSellers(entries);
        int rank = 1;
        for (MaterialEntry e : top) {
            Label rankLbl = new Label("#" + rank++);
            rankLbl.setStyle("-fx-text-fill: #7F8C8D; -fx-font-size: 12px; -fx-min-width: 28;");
            Label nameLbl = new Label(capitalize(e.getMaterial()));
            nameLbl.setFont(Font.font("Segoe UI", FontWeight.SEMI_BOLD, 13));
            Region spacer = new Region(); HBox.setHgrow(spacer, Priority.ALWAYS);
            Label qtyLbl = UIHelper.successBadge(String.format("%.0f kg", e.getQuantity()));
            HBox row = new HBox(8, rankLbl, nameLbl, spacer, qtyLbl);
            row.setPadding(new Insets(6, 10, 6, 10));
            row.setStyle("-fx-background-color: #F8F9FA; -fx-background-radius: 8;");
            list.getChildren().add(row);
        }
        if (list.getChildren().isEmpty()) list.getChildren().add(new Label("No data available."));

        VBox card = new VBox(12, title, new Separator(), list);
        card.setPadding(new Insets(18, 20, 18, 20));
        card.setStyle(
            "-fx-background-color: white;" +
            "-fx-background-radius: 12;" +
            "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.09), 12, 0, 0, 4);"
        );
        return card;
    }

    private VBox buildSlowMoversCard(List<MaterialEntry> entries) {
        Label title = new Label("🐢 Slow Movers");
        title.setFont(Font.font("Segoe UI", FontWeight.BOLD, 15));
        title.setStyle("-fx-text-fill: #2C3E50;");

        VBox list = new VBox(8);
        List<MaterialEntry> slow = MaterialController.getSlowMovers(entries);
        for (MaterialEntry e : slow) {
            Label nameLbl = new Label(capitalize(e.getMaterial()));
            nameLbl.setFont(Font.font("Segoe UI", FontWeight.SEMI_BOLD, 13));
            Region spacer = new Region(); HBox.setHgrow(spacer, Priority.ALWAYS);
            Label qtyLbl = e.isLowStock()
                ? UIHelper.dangerBadge(String.format("%.0f kg", e.getQuantity()))
                : UIHelper.warningBadge(String.format("%.0f kg", e.getQuantity()));
            HBox row = new HBox(8, nameLbl, spacer, qtyLbl);
            row.setPadding(new Insets(6, 10, 6, 10));
            row.setStyle("-fx-background-color: #FEF9E7; -fx-background-radius: 8;");
            list.getChildren().add(row);
        }
        if (list.getChildren().isEmpty()) list.getChildren().add(new Label("No data available."));

        VBox card = new VBox(12, title, new Separator(), list);
        card.setPadding(new Insets(18, 20, 18, 20));
        card.setStyle(
            "-fx-background-color: white;" +
            "-fx-background-radius: 12;" +
            "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.09), 12, 0, 0, 4);"
        );
        return card;
    }

    private String capitalize(String s) {
        if (s == null || s.isEmpty()) return s;
        return Character.toUpperCase(s.charAt(0)) + s.substring(1);
    }
}
