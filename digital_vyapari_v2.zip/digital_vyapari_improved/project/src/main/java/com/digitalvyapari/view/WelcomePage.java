package com.digitalvyapari.view;

import javafx.animation.FadeTransition;
import javafx.animation.ScaleTransition;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.effect.DropShadow;
import javafx.scene.effect.GaussianBlur;
import javafx.scene.image.Image;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.util.Duration;

public class WelcomePage extends Application {

    @Override
    public void start(Stage stage) {
        stage.setTitle("Digital Vyapari - Welcome");

        // ── Background ──────────────────────────────────────────────────────
        StackPane root = buildBackground(stage);

        // ── Gradient overlay ────────────────────────────────────────────────
        Region overlay = new Region();
        overlay.setStyle("-fx-background-color: linear-gradient(to bottom right, rgba(10,20,40,0.78), rgba(15,60,100,0.82));");
        overlay.prefWidthProperty().bind(stage.widthProperty());
        overlay.prefHeightProperty().bind(stage.heightProperty());

        // ── Left branding panel ─────────────────────────────────────────────
        VBox brandPanel = buildBrandPanel();

        // ── Right login card ─────────────────────────────────────────────────
        VBox loginCard = buildLoginCard(stage);

        // ── Layout ──────────────────────────────────────────────────────────
        HBox mainContent = new HBox(60, brandPanel, loginCard);
        mainContent.setAlignment(Pos.CENTER);
        mainContent.setPadding(new Insets(60));

        StackPane layered = new StackPane(overlay, mainContent);
        root.getChildren().add(layered);

        // Fade in
        FadeTransition fade = new FadeTransition(Duration.seconds(1.2), mainContent);
        fade.setFromValue(0); fade.setToValue(1); fade.play();

        Scene scene = new Scene(root, 1280, 800);
        stage.setScene(scene);
        stage.setFullScreen(true);
        stage.show();
    }

    private StackPane buildBackground(Stage stage) {
        StackPane bg = new StackPane();
        try {
            BackgroundImage bgImg = new BackgroundImage(
                new Image("Assets/Images/front_welcome.jpg", 1600, 900, false, true),
                BackgroundRepeat.NO_REPEAT, BackgroundRepeat.NO_REPEAT,
                BackgroundPosition.CENTER, BackgroundSize.DEFAULT
            );
            bg.setBackground(new Background(bgImg));
        } catch (Exception e) {
            bg.setStyle("-fx-background-color: #0d2137;");
        }
        return bg;
    }

    private VBox buildBrandPanel() {
        // Logo circle
        Circle logoBg = new Circle(50);
        logoBg.setFill(Color.web("#27AE60"));
        Label logoText = new Label("DV");
        logoText.setFont(Font.font("Segoe UI", FontWeight.BOLD, 32));
        logoText.setStyle("-fx-text-fill: white;");
        StackPane logo = new StackPane(logoBg, logoText);

        Text appName = new Text("Digital Vyapari");
        appName.setFont(Font.font("Segoe UI", FontWeight.EXTRA_BOLD, 52));
        appName.setFill(Color.WHITE);
        appName.setEffect(new DropShadow(20, Color.rgb(0, 0, 0, 0.7)));

        Text tagline = new Text("व्यापारी का डिजिटल साथी");
        tagline.setFont(Font.font("Segoe UI", FontWeight.SEMI_BOLD, 22));
        tagline.setFill(Color.web("#48D1CC"));

        // Feature list
        VBox features = new VBox(12);
        String[] featureList = {
            "✅  Manage Farmers & Suppliers",
            "✅  Real-time Inventory Tracking",
            "✅  Smart Sales Dashboard",
            "✅  PDF Invoice Generation",
            "✅  Customer Order Management"
        };
        for (String f : featureList) {
            Label lbl = new Label(f);
            lbl.setFont(Font.font("Segoe UI", 15));
            lbl.setStyle("-fx-text-fill: rgba(255,255,255,0.85);");
            features.getChildren().add(lbl);
        }

        VBox panel = new VBox(20, logo, appName, tagline, features);
        panel.setAlignment(Pos.CENTER_LEFT);
        panel.setMaxWidth(520);
        return panel;
    }

    private VBox buildLoginCard(Stage stage) {
        Label title = new Label("Get Started");
        title.setFont(Font.font("Segoe UI", FontWeight.BOLD, 26));
        title.setStyle("-fx-text-fill: #2C3E50;");

        Label subtitle = new Label("Choose your role to login or register");
        subtitle.setStyle("-fx-text-fill: #7F8C8D; -fx-font-size: 14px;");

        // Vyapari button
        Button vyapariBtn = createRoleButton(
            "🌾  Login as Vyapari",
            "Farmer / Supplier management",
            "#27AE60", "#1E8449"
        );
        vyapariBtn.setOnAction(e -> openLogin(stage, "Vyapari"));

        // Shopkeeper button
        Button shopkeeperBtn = createRoleButton(
            "🏪  Login as Shopkeeper",
            "Buy materials & manage orders",
            "#3498DB", "#2980B9"
        );
        shopkeeperBtn.setOnAction(e -> openLogin(stage, "Shopkeeper"));

        // Separator
        Label orLabel = new Label("─────  or  ─────");
        orLabel.setStyle("-fx-text-fill: #BDC3C7; -fx-font-size: 13px;");

        // Exit button
        Button exitBtn = new Button("✕  Exit Application");
        exitBtn.setStyle(
            "-fx-background-color: transparent;" +
            "-fx-border-color: #E74C3C;" +
            "-fx-border-width: 1.5;" +
            "-fx-border-radius: 8;" +
            "-fx-background-radius: 8;" +
            "-fx-text-fill: #E74C3C;" +
            "-fx-font-size: 14px;" +
            "-fx-cursor: hand;" +
            "-fx-pref-width: 280px;"
        );
        exitBtn.setOnAction(e -> stage.close());

        VBox card = new VBox(18, title, subtitle, vyapariBtn, shopkeeperBtn, orLabel, exitBtn);
        card.setAlignment(Pos.CENTER);
        card.setPadding(new Insets(40, 45, 40, 45));
        card.setMaxWidth(360);
        card.setStyle(
            "-fx-background-color: rgba(255,255,255,0.97);" +
            "-fx-background-radius: 18;" +
            "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.35), 30, 0, 0, 8);"
        );

        // Scale in animation
        card.setScaleX(0.85); card.setScaleY(0.85);
        ScaleTransition st = new ScaleTransition(Duration.millis(500), card);
        st.setToX(1); st.setToY(1); st.play();

        return card;
    }

    private Button createRoleButton(String title, String subtitle, String color, String hover) {
        Label titleLbl = new Label(title);
        titleLbl.setFont(Font.font("Segoe UI", FontWeight.BOLD, 15));
        titleLbl.setStyle("-fx-text-fill: white;");

        Label subLbl = new Label(subtitle);
        subLbl.setFont(Font.font("Segoe UI", 12));
        subLbl.setStyle("-fx-text-fill: rgba(255,255,255,0.8);");

        VBox content = new VBox(2, titleLbl, subLbl);
        content.setAlignment(Pos.CENTER_LEFT);

        Button btn = new Button();
        btn.setGraphic(content);
        btn.setPrefWidth(280);
        btn.setPrefHeight(64);
        String baseStyle = String.format(
            "-fx-background-color: %s;" +
            "-fx-background-radius: 10;" +
            "-fx-cursor: hand;" +
            "-fx-padding: 10 18 10 18;", color);
        String hoverStyle = String.format(
            "-fx-background-color: %s;" +
            "-fx-background-radius: 10;" +
            "-fx-cursor: hand;" +
            "-fx-padding: 10 18 10 18;" +
            "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.3), 10, 0, 0, 3);", hover);
        btn.setStyle(baseStyle);
        btn.setOnMouseEntered(e -> btn.setStyle(hoverStyle));
        btn.setOnMouseExited(e -> btn.setStyle(baseStyle));
        return btn;
    }

    private void openLogin(Stage stage, String role) {
        try {
            new LoginRegisterPage(role).start(stage);
        } catch (Exception ex) {
            ex.printStackTrace();
            Alert a = new Alert(Alert.AlertType.ERROR);
            a.setTitle("Error"); a.setContentText(ex.getMessage());
            a.showAndWait();
        }
    }
}
