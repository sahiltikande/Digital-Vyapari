# 🏪 Digital Vyapari v2.0 — Improved Edition

A modern JavaFX application for managing farmer supplies, inventory, and shopkeeper orders — powered by Firebase.

---

## 🚀 What's New in v2.0

| Feature | Old Version | New Version |
|--------|-------------|-------------|
| UI Style | Inline styles, inconsistent | Centralized CSS + UIHelper factory |
| Navigation | Button-grid home | Professional sidebar navigation |
| Dashboard | None | Stats cards + bar/pie charts |
| AI Insights | None | Top sellers, slow movers, alerts |
| Search & Filter | None | Live search + category filter |
| Dark Mode | None | Toggle in sidebar |
| Export | None | CSV export for materials & orders |
| PDF Invoice | Basic | Professional iText layout |
| Code Quality | Spaghetti | MVC with clean separation |
| Error Handling | Minimal | Comprehensive with UI feedback |

---

## 📁 Project Structure

```
src/main/java/com/digitalvyapari/
├── Main.java                        ← Entry point
├── Controller/
│   ├── FarmerController.java        ← Firebase submit + PDF
│   ├── LoginController.java         ← Firebase Auth REST API
│   ├── MaterialController.java      ← Data + AI insights
│   └── ShopkeeperController.java    ← Orders + inventory
├── Utils/
│   ├── FirebaseUtil.java            ← Firebase init (thread-safe)
│   ├── Session.java                 ← User session + dark mode
│   └── UIHelper.java                ← Centralized UI factory
└── view/
    ├── WelcomePage.java             ← Landing page
    ├── LoginRegisterPage.java       ← Auth screen
    ├── Sidebar.java                 ← Reusable sidebar nav
    ├── VyapariHome.java             ← Vyapari dashboard
    ├── Farmer.java                  ← Farmer entry form
    ├── MaterialsView.java           ← Inventory table + search
    ├── AnalyticsView.java           ← Charts + AI insights
    ├── ShopkeeperHomePage.java      ← Shopkeeper browse + buy
    ├── OrdersPage.java              ← Orders table
    └── AboutUs.java                 ← Team info page
```

---

## 🛠️ Prerequisites

| Tool | Required Version |
|------|-----------------|
| Java JDK | 17 or higher |
| Maven | 3.8+ |
| Internet | For Firebase connection |

---

## ⚡ How to Run

### Option 1: Maven (Recommended)

```bash
# Step 1: Navigate to project folder
cd digital_vyapari_improved/project

# Step 2: Clean and build
mvn clean package -DskipTests

# Step 3: Run
mvn javafx:run
```

### Option 2: Direct JAR (after build)

```bash
cd digital_vyapari_improved/project
mvn clean package -DskipTests
java -jar target/digital-vyapari-2.0-SNAPSHOT-shaded.jar
```

### Option 3: VS Code / IntelliJ

1. Open the `project` folder
2. Maven will auto-resolve dependencies
3. Run `Main.java`

---

## 🔑 Firebase Configuration

The `firebase-key.json` is already included in `src/main/resources/`.

**Firebase Project:** `myfxproject-cc36b`  
**Database URL:** `https://myfxproject-cc36b-default-rtdb.firebaseio.com/`

> ⚠️ If you want to use your own Firebase project:
> 1. Go to Firebase Console → Project Settings → Service Accounts
> 2. Generate a new private key
> 3. Replace `src/main/resources/firebase-key.json`
> 4. Update the database URL in `FirebaseUtil.java`

---

## 🗄️ Firebase Database Structure

```
myfxproject-cc36b/
├── users/
│   └── {uid}/
│       ├── email, name, mobile, address, role, createdAt
├── farmer_data/
│   └── {key}/
│       ├── name, email, address
│       ├── materialType, material
│       ├── quantity, rate, finalPrice
│       ├── timestamp, status
├── orders/
│   └── {key}/
│       ├── name, address, material, type
│       ├── quantity, rate, total
│       ├── timestamp, status
└── posts/
    └── {key}/
        └── type, material, quantity, price
```

---

## 🤖 AI Features

The app includes rule-based "smart" features from `MaterialController`:

- **Top Sellers** — Sorted by quantity descending
- **Slow Movers** — Items with lowest stock
- **Low Stock Alerts** — Items below 10 kg threshold
- **Auto-complete Search** — Filters by partial material name
- **Smart Insights** — Dashboard summary with color-coded cards
- **Value Analysis** — Total inventory value per category

---

## 🎨 UI Design System

All UI components go through `UIHelper.java`:

```java
// Buttons
UIHelper.primaryButton("Text")    // Green
UIHelper.secondaryButton("Text")  // Blue
UIHelper.dangerButton("Text")     // Red
UIHelper.warningButton("Text")    // Orange
UIHelper.outlineButton("Text")    // Outlined green

// Fields
UIHelper.styledTextField("Placeholder")
UIHelper.styledPasswordField("Placeholder")

// Labels / Badges
UIHelper.successBadge("In Stock")
UIHelper.dangerBadge("Low Stock")
UIHelper.warningBadge("Pending")
UIHelper.infoBadge("Category")

// Alerts
UIHelper.showInfo("Title", "Message")
UIHelper.showError("Title", "Message")
UIHelper.showConfirm("Title", "Message")  // returns boolean
```

---

## 📦 Dependencies

| Library | Version | Purpose |
|---------|---------|---------|
| JavaFX | 21.0.1 | UI framework |
| Firebase Admin SDK | 9.5.0 | Realtime database |
| Google Auth | 1.19.0 | Firebase credentials |
| iText PDF | 5.5.13.3 | Invoice generation |
| Apache POI | 5.2.3 | Excel export |
| ControlsFX | 11.1.2 | Extra UI components |
| JSON (org.json) | 20230227 | Firebase Auth REST |

---

## 🐛 Troubleshooting

| Problem | Solution |
|---------|----------|
| `firebase-key.json not found` | Check file is in `src/main/resources/` |
| Firebase connection error | Check internet connection |
| JavaFX not found | Run with `mvn javafx:run`, not bare `java` |
| Login fails | Verify Firebase Auth is enabled in console |
| PDF not opening | Check default PDF viewer is set |

---

## 👥 Team

- **Siddhesh Dhumal** — Lead Developer
- **Pratik Pacharne** — Backend Developer  
- **Gaurav Kate** — UI Developer
- **Kiran Jathar** — Database Developer
- **Mr. Shashikant Bagal** — Project Guide

---

*Built with ❤️ using Java, JavaFX, and Firebase*
